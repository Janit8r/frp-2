@echo off
echo 正在部署Alist WASM到Cloudflare Workers...

:: 设置Go环境变量
set GOOS=js
set GOARCH=wasm

:: 构建WASM二进制
echo 正在构建WASM二进制...
go build -o alist.wasm wasm.go

:: 检查构建是否成功
if not exist alist.wasm (
    echo 构建失败，未生成alist.wasm文件
    exit /b 1
)

:: 将WASM二进制转换为base64
echo 正在将WASM二进制转换为base64...
certutil -encode alist.wasm alist.wasm.b64
findstr /v /r "^-" alist.wasm.b64 > alist.wasm.b64.tmp
move /y alist.wasm.b64.tmp alist.wasm.b64

:: 创建worker.js的临时副本
copy worker.js worker.js.temp

:: 在worker.js中替换占位符
echo 正在注入WASM二进制到worker.js...
:: 使用PowerShell来处理替换
powershell -Command "$content = Get-Content -Raw worker.js.temp; $base64 = Get-Content -Raw alist.wasm.b64; $content = $content -replace '{{ WASM_BINARY }}', $base64; Set-Content -Path worker.js -Value $content"

:: 清理临时文件
del worker.js.temp
del alist.wasm.b64

:: 使用wrangler部署
echo 正在部署到Cloudflare Workers...
npx wrangler publish

echo 部署完成！ 