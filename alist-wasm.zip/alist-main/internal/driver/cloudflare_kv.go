package driver

import (
	"context"
	"fmt"
	"io"
	"path"
	"strings"
	"syscall/js"
	"time"

	"github.com/alist-org/alist/v3/internal/model"
	"github.com/alist-org/alist/v3/pkg/utils"
)

// CloudflareKV 是Cloudflare KV存储的驱动器实现
type CloudflareKV struct {
	model.Storage
	Addition
}

// Addition 存储配置信息
type Addition struct {
	NamespaceID string `json:"namespace_id" required:"true"`
	AccountID   string `json:"account_id" required:"true"`
	APIToken    string `json:"api_token" required:"true"`
}

// 确保实现Storage接口
var _ model.Driver = (*CloudflareKV)(nil)

// 初始化
func (d *CloudflareKV) Init(ctx context.Context) error {
	// 在WebAssembly环境中初始化
	// 这里可以验证凭据，但在Worker环境中通常使用绑定的KV命名空间
	return nil
}

// 内容类型
func (d *CloudflareKV) GetAddition() interface{} {
	return d.Addition
}

// 生成签名的文件URL
func (d *CloudflareKV) Link(ctx context.Context, file model.Obj, args model.LinkArgs) (*model.Link, error) {
	// 在Cloudflare Workers中，我们通过Worker代理访问KV数据
	// 返回一个指向Worker路由的URL
	fileName := file.GetName()
	filePath := args.Path
	
	// 调用JavaScript来获取Worker URL
	workerURLFunc := js.Global().Get("getWorkerURL")
	if workerURLFunc.IsUndefined() {
		return nil, fmt.Errorf("getWorkerURL function not found in global scope")
	}
	
	workerURL := workerURLFunc.Invoke(filePath).String()
	
	// 构建完整URL
	fullURL := fmt.Sprintf("%s/api/raw/%s", workerURL, strings.TrimPrefix(filePath, "/"))
	
	return &model.Link{
		URL: fullURL,
		Header: map[string]string{
			"Content-Disposition": fmt.Sprintf(`attachment; filename="%s"`, fileName),
		},
	}, nil
}

// 列出目录内容
func (d *CloudflareKV) List(ctx context.Context, dir model.Obj, args model.ListArgs) ([]model.Obj, error) {
	// 调用JavaScript来获取KV键列表
	dirPath := dir.GetPath()
	jsListFunc := js.Global().Get("listKVKeys")
	if jsListFunc.IsUndefined() {
		return nil, fmt.Errorf("listKVKeys function not found in global scope")
	}
	
	// 调用JavaScript函数获取结果
	jsResult := jsListFunc.Invoke(d.NamespaceID, dirPath)
	if jsResult.IsNull() || jsResult.IsUndefined() {
		return []model.Obj{}, nil
	}
	
	// 解析JavaScript返回的数组
	resultLen := jsResult.Length()
	var objects []model.Obj
	
	for i := 0; i < resultLen; i++ {
		jsObj := jsResult.Index(i)
		
		name := jsObj.Get("name").String()
		isDir := jsObj.Get("isDir").Bool()
		size := int64(jsObj.Get("size").Int())
		modifiedStr := jsObj.Get("modified").String()
		
		// 解析修改时间
		modified, err := time.Parse(time.RFC3339, modifiedStr)
		if err != nil {
			modified = time.Now()
		}
		
		// 创建Obj对象
		var obj model.Obj
		if isDir {
			obj = &model.Folder{
				Name:     name,
				Modified: modified,
				Path:     path.Join(dirPath, name),
			}
		} else {
			obj = &model.File{
				Name:     name,
				Size:     size,
				Modified: modified,
				Path:     path.Join(dirPath, name),
			}
		}
		
		objects = append(objects, obj)
	}
	
	return objects, nil
}

// 获取对象
func (d *CloudflareKV) Get(ctx context.Context, path string) (model.Obj, error) {
	// 调用JavaScript来获取对象信息
	jsGetFunc := js.Global().Get("getKVObject")
	if jsGetFunc.IsUndefined() {
		return nil, fmt.Errorf("getKVObject function not found in global scope")
	}
	
	jsResult := jsGetFunc.Invoke(d.NamespaceID, path)
	if jsResult.IsNull() || jsResult.IsUndefined() {
		return nil, fmt.Errorf("object not found: %s", path)
	}
	
	name := jsResult.Get("name").String()
	isDir := jsResult.Get("isDir").Bool()
	size := int64(jsResult.Get("size").Int())
	modifiedStr := jsResult.Get("modified").String()
	
	// 解析修改时间
	modified, err := time.Parse(time.RFC3339, modifiedStr)
	if err != nil {
		modified = time.Now()
	}
	
	// 创建Obj对象
	var obj model.Obj
	if isDir {
		obj = &model.Folder{
			Name:     name,
			Modified: modified,
			Path:     path,
		}
	} else {
		obj = &model.File{
			Name:     name,
			Size:     size,
			Modified: modified,
			Path:     path,
		}
	}
	
	return obj, nil
}

// 其他必要方法的最小实现
func (d *CloudflareKV) MakeDir(ctx context.Context, path string) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *CloudflareKV) Move(ctx context.Context, srcObj, dstDir model.Obj) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *CloudflareKV) Rename(ctx context.Context, srcObj model.Obj, newName string) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *CloudflareKV) Copy(ctx context.Context, srcObj, dstDir model.Obj) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *CloudflareKV) Remove(ctx context.Context, obj model.Obj) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *CloudflareKV) Put(ctx context.Context, dstDir model.Obj, stream model.FileStreamer, up model.UpdateProgress) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

// 不支持的方法
func (d *CloudflareKV) Other(ctx context.Context, args model.OtherArgs) (interface{}, error) {
	return nil, fmt.Errorf("operation not supported")
}

func init() {
	RegisterDriver("cloudflare_kv", func() model.Driver {
		return &CloudflareKV{}
	})
} 