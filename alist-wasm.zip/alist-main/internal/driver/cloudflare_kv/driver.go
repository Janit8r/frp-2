package cloudflare_kv

import (
	"context"
	"fmt"
	"net/http"
	"path"
	"strings"
	"syscall/js"
	"time"

	"github.com/alist-org/alist/v3/internal/driver"
	"github.com/alist-org/alist/v3/internal/model"
)

// Driver结构定义
type Driver struct {
	storage model.Storage
	Addition
}

// 确保实现Driver接口
var _ driver.Driver = (*Driver)(nil)

// GetStorage 实现driver.Driver接口
func (d *Driver) GetStorage() *model.Storage {
	return &d.storage
}

// SetStorage 实现driver.Driver接口
func (d *Driver) SetStorage(storage model.Storage) {
	d.storage = storage
}

// 初始化
func (d *Driver) Init(ctx context.Context) error {
	// 在WebAssembly环境中初始化
	// 这里可以验证凭据，但在Worker环境中通常使用绑定的KV命名空间
	return nil
}

// Drop 释放资源
func (d *Driver) Drop(ctx context.Context) error {
	return nil
}

// 生成签名的文件URL
func (d *Driver) Link(ctx context.Context, file model.Obj, args model.LinkArgs) (*model.Link, error) {
	// 在Cloudflare Workers中，我们通过Worker代理访问KV数据
	// 返回一个指向Worker路由的URL
	fileName := file.GetName()
	filePath := file.GetPath()
	
	// 调用JavaScript来获取Worker URL
	workerURLFunc := js.Global().Get("getWorkerURL")
	if workerURLFunc.IsUndefined() {
		return nil, fmt.Errorf("getWorkerURL function not found in global scope")
	}
	
	workerURL := workerURLFunc.Invoke(filePath).String()
	
	// 构建完整URL
	fullURL := fmt.Sprintf("%s/api/raw/%s", workerURL, strings.TrimPrefix(filePath, "/"))
	
	// 创建正确的Header类型
	header := http.Header{}
	header.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="%s"`, fileName))
	
	return &model.Link{
		URL:    fullURL,
		Header: header,
	}, nil
}

// 列出目录内容
func (d *Driver) List(ctx context.Context, dir model.Obj, args model.ListArgs) ([]model.Obj, error) {
	// 调用JavaScript来获取KV键列表
	dirPath := dir.GetPath()
	jsListFunc := js.Global().Get("listKVKeys")
	if jsListFunc.IsUndefined() {
		return nil, fmt.Errorf("listKVKeys function not found in global scope")
	}
	
	// 调用JavaScript函数获取结果
	jsResult := jsListFunc.Invoke(d.NamespaceID, dirPath)
	if jsResult.IsNull() || jsResult.IsUndefined() {
		return []model.Obj{}, nil
	}
	
	// 解析JavaScript返回的数组
	resultLen := jsResult.Length()
	var objects []model.Obj
	
	for i := 0; i < resultLen; i++ {
		jsObj := jsResult.Index(i)
		
		name := jsObj.Get("name").String()
		isDir := jsObj.Get("isDir").Bool()
		size := int64(jsObj.Get("size").Int())
		modifiedStr := jsObj.Get("modified").String()
		
		// 解析修改时间
		modified, err := time.Parse(time.RFC3339, modifiedStr)
		if err != nil {
			modified = time.Now()
		}
		
		// 创建Obj对象
		var obj model.Obj
		objPath := path.Join(dirPath, name)
		
		if isDir {
			obj = &model.Object{
				Name:     name,
				Modified: modified,
				Path:     objPath,
				IsFolder: true,
			}
		} else {
			obj = &model.Object{
				Name:     name,
				Size:     size,
				Modified: modified,
				Path:     objPath,
				IsFolder: false,
			}
		}
		
		objects = append(objects, obj)
	}
	
	return objects, nil
}

// 获取对象
func (d *Driver) Get(ctx context.Context, path string) (model.Obj, error) {
	// 调用JavaScript来获取对象信息
	jsGetFunc := js.Global().Get("getKVObject")
	if jsGetFunc.IsUndefined() {
		return nil, fmt.Errorf("getKVObject function not found in global scope")
	}
	
	jsResult := jsGetFunc.Invoke(d.NamespaceID, path)
	if jsResult.IsNull() || jsResult.IsUndefined() {
		return nil, fmt.Errorf("object not found: %s", path)
	}
	
	name := jsResult.Get("name").String()
	isDir := jsResult.Get("isDir").Bool()
	size := int64(jsResult.Get("size").Int())
	modifiedStr := jsResult.Get("modified").String()
	
	// 解析修改时间
	modified, err := time.Parse(time.RFC3339, modifiedStr)
	if err != nil {
		modified = time.Now()
	}
	
	// 创建Obj对象
	return &model.Object{
		Name:     name,
		Size:     size,
		Modified: modified,
		Path:     path,
		IsFolder: isDir,
	}, nil
}

// 其他必要方法的最小实现
func (d *Driver) MakeDir(ctx context.Context, path string) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *Driver) Move(ctx context.Context, srcObj, dstDir model.Obj) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *Driver) Rename(ctx context.Context, srcObj model.Obj, newName string) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *Driver) Copy(ctx context.Context, srcObj, dstDir model.Obj) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *Driver) Remove(ctx context.Context, obj model.Obj) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

func (d *Driver) Put(ctx context.Context, dstDir model.Obj, stream model.FileStreamer, up model.UpdateProgress) error {
	return fmt.Errorf("operation not supported in read-only mode")
}

// 不支持的方法
func (d *Driver) Other(ctx context.Context, args model.OtherArgs) (interface{}, error) {
	return nil, fmt.Errorf("operation not supported")
} 