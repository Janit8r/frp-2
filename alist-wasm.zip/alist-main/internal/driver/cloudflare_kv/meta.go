package cloudflare_kv

import (
	"github.com/alist-org/alist/v3/internal/driver"
	"github.com/alist-org/alist/v3/internal/op"
)

type Addition struct {
	NamespaceID string `json:"namespace_id" required:"true"`
	AccountID   string `json:"account_id" required:"true"`
	APIToken    string `json:"api_token" required:"true"`
}

// Driver结构定义已移至driver.go文件

func (d *Driver) Config() driver.Config {
	return driver.Config{
		Name:        "CloudflareKV",
		DefaultRoot: "/",
		NoCache:     false,
	}
}

func (*Driver) GetAddition() driver.Additional {
	return &Addition{}
}

// 不要在这里重复定义GetStorage和SetStorage，它们已经在driver.go中定义

func init() {
	op.RegisterDriver(func() driver.Driver {
		return &Driver{}
	})
} 