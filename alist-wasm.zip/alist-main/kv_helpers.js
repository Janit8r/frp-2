/**
 * Alist Cloudflare KV 辅助函数
 * 提供WebAssembly调用的KV操作接口
 */

// 全局Worker URL获取函数
globalThis.getWorkerURL = function(path) {
  return self.location.origin;
};

// 列出KV键
globalThis.listKVKeys = async function(namespaceId, prefix) {
  try {
    // 通过KV绑定获取列表
    const keys = await ALIST_KV.list({ prefix: prefix });
    
    // 处理结果，模拟文件结构
    const results = [];
    const seenDirs = new Set();
    
    // 添加文件和直接子目录
    for (const key of keys.keys) {
      const fullPath = key.name;
      
      // 跳过前缀本身
      if (fullPath === prefix) continue;
      
      // 获取相对路径
      const relativePath = fullPath.slice(prefix.length > 0 ? prefix.length + 1 : 0);
      
      // 检查是否是当前目录下的直接子项
      const parts = relativePath.split('/');
      
      if (parts.length > 1 && parts[0] !== '') {
        // 这是一个子目录中的项，只添加第一级目录
        const dirName = parts[0];
        if (!seenDirs.has(dirName)) {
          seenDirs.add(dirName);
          results.push({
            name: dirName,
            isDir: true,
            size: 0,
            modified: new Date().toISOString()
          });
        }
      } else if (parts[0] !== '') {
        // 这是一个文件
        // 获取元数据
        const metadata = key.metadata || {};
        
        results.push({
          name: parts[0],
          isDir: false,
          size: metadata.size || 0,
          modified: metadata.modified || new Date().toISOString()
        });
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error listing KV keys:', error);
    return [];
  }
};

// 获取KV对象
globalThis.getKVObject = async function(namespaceId, path) {
  try {
    // 从路径中提取对象名
    const parts = path.split('/');
    const name = parts[parts.length - 1];
    
    // 检查对象是否存在
    const value = await ALIST_KV.get(path, { type: "text" });
    if (value === null) {
      // 检查是否是目录
      const keys = await ALIST_KV.list({ prefix: path + '/' });
      if (keys.keys.length > 0) {
        return {
          name: name,
          isDir: true,
          size: 0,
          modified: new Date().toISOString()
        };
      }
      return null;
    }
    
    // 获取对象元数据
    const metadata = await ALIST_KV.getWithMetadata(path, { type: "text" });
    const metaObj = metadata.metadata || {};
    
    return {
      name: name,
      isDir: false,
      size: value.length,
      modified: metaObj.modified || new Date().toISOString()
    };
  } catch (error) {
    console.error('Error getting KV object:', error);
    return null;
  }
};

// 获取KV对象内容
globalThis.getKVContent = async function(namespaceId, path) {
  try {
    // 获取对象内容
    const value = await ALIST_KV.get(path, { type: "arrayBuffer" });
    if (value === null) {
      return null;
    }
    
    return value;
  } catch (error) {
    console.error('Error getting KV content:', error);
    return null;
  }
}; 