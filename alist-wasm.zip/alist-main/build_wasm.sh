#!/bin/bash

# 检查Go版本
GO_VERSION=$(go version | grep -oP "go\d+\.\d+\.\d+" | grep -oP "\d+\.\d+")
REQUIRED_VERSION="1.23"

# 版本比较函数
version_lt() {
    [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" = "$1" ]
}

# 检查Go版本是否满足要求
if version_lt "$GO_VERSION" "$REQUIRED_VERSION"; then
    echo "错误: 当前Go版本 $GO_VERSION 太低，AList WebAssembly编译需要Go $REQUIRED_VERSION+"
    echo "请升级Go版本后再尝试编译"
    exit 1
fi

echo "检测到Go版本: $GO_VERSION，满足编译要求"

# 设置WebAssembly编译环境变量
export GOOS=js
export GOARCH=wasm

# 创建输出目录
mkdir -p dist

# 编译前确保依赖更新
echo "更新Go依赖..."
go mod tidy

# 编译WebAssembly
echo "编译Go WebAssembly..."
go build -o dist/main.wasm wasm.go

# 检查编译结果
if [ $? -ne 0 ]; then
    echo "编译失败，请查看上方错误信息"
    exit 1
fi

# 复制必要的JS文件
echo "复制wasm_exec.js和其他必要文件..."
cp "$(go env GOROOT)/misc/wasm/wasm_exec.js" dist/
cp worker.js dist/
cp kv_helpers.js dist/

# 检查wrangler.toml是否存在并复制
if [ -f "wrangler.toml" ]; then
    cp wrangler.toml dist/
else
    echo "警告: 找不到wrangler.toml配置文件"
fi

# 列出编译结果
echo "编译完成，生成的文件列表:"
ls -la dist/

echo "WebAssembly编译成功！文件已存放在dist目录中" 