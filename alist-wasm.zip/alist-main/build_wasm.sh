#!/bin/bash

# 确保GOROOT和GOPATH已设置
if [ -z "$GOROOT" ]; then
  echo "GOROOT环境变量未设置，请设置Go安装路径"
  exit 1
fi

if [ -z "$GOPATH" ]; then
  echo "GOPATH环境变量未设置，使用默认位置"
  export GOPATH=$HOME/go
fi

# 确保tinygo已安装（可选，如果使用TinyGo来减小WASM大小）
# if ! command -v tinygo &> /dev/null; then
#   echo "tinygo未找到，请安装tinygo以获得更小的WASM文件"
#   exit 1
# fi

# 设置WASM编译环境变量
export GOOS=js
export GOARCH=wasm

# 创建输出目录
mkdir -p dist

# 编译主WASM模块
echo "编译Go WebAssembly..."
go build -o dist/main.wasm wasm.go

# 复制JS胶水代码
echo "复制wasm_exec.js..."
cp "$GOROOT/misc/wasm/wasm_exec.js" dist/

# 复制worker.js
echo "复制worker.js..."
cp worker.js dist/

# 使用tinygo编译更小的WASM（可选）
# echo "使用TinyGo编译更小的WebAssembly..."
# tinygo build -o dist/main.tiny.wasm -target wasm wasm.go

# 计算文件大小
WASM_SIZE=$(ls -lh dist/main.wasm | awk '{print $5}')
echo "WebAssembly编译完成，大小: $WASM_SIZE"

echo "---------------------------------------------"
echo "编译完成！文件位于dist/目录"
echo "将dist/目录下的所有文件上传到Cloudflare Workers"
echo "---------------------------------------------" 