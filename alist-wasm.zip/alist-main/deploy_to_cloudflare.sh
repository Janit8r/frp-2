#!/bin/bash

# 部署Alist WASM到Cloudflare Workers的脚本
echo "正在部署Alist WASM到Cloudflare Workers..."

# 确保构建脚本可执行
chmod +x build_wasm.sh

# 构建WASM二进制
./build_wasm.sh

# 检查构建是否成功
if [ ! -f "alist.wasm" ]; then
  echo "构建失败，未生成alist.wasm文件"
  exit 1
fi

# 将WASM二进制转换为base64字符串
echo "正在将WASM二进制转换为base64..."
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
  # Windows环境
  certutil -encode alist.wasm alist.wasm.b64
  # 删除certutil添加的头尾行
  sed -i '1d;$d' alist.wasm.b64
else
  # Linux/Mac环境
  base64 -w 0 alist.wasm > alist.wasm.b64
fi

# 创建worker.js的临时副本
cp worker.js worker.js.temp

# 在worker.js中替换占位符
echo "正在注入WASM二进制到worker.js..."
WASM_B64=$(cat alist.wasm.b64)
# 使用sed替换占位符
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
  # Windows环境
  sed "s|{{ WASM_BINARY }}|${WASM_B64}|g" worker.js.temp > worker.js
else
  # Linux/Mac环境
  sed "s|{{ WASM_BINARY }}|${WASM_B64}|g" worker.js.temp > worker.js
fi

# 清理临时文件
rm worker.js.temp alist.wasm.b64

# 使用wrangler部署
echo "正在部署到Cloudflare Workers..."
npx wrangler publish

echo "部署完成！" 