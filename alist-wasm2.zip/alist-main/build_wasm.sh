#!/bin/bash

# Build script for WASM version of Alist
echo "Building Alist WASM version for Cloudflare Workers..."

# Set environment variables for WebAssembly
export GOOS=js
export GOARCH=wasm

# Build the WASM binary
go build -o alist.wasm wasm.go

echo "Build complete! Outputted as alist.wasm"
echo "Use this file with Cloudflare Workers to deploy your application." 