/**
 * kv_helpers.js
 * Cloudflare Workers KV 存储辅助函数
 * 提供与Cloudflare KV存储交互的功能
 */

/**
 * KV存储操作类
 * 提供对Cloudflare KV的读写操作
 */
class KVHelpers {
  /**
   * 创建KVHelpers实例
   * @param {Object} NAMESPACE - Cloudflare KV绑定的命名空间
   */
  constructor(NAMESPACE) {
    this.namespace = NAMESPACE;
    this.cache = new Map();
    this.cacheEnabled = true;
  }

  /**
   * 从KV存储读取值
   * @param {string} key - 要读取的键
   * @returns {Promise<string|null>} - 读取的值或null
   */
  async get(key) {
    // 先检查缓存
    if (this.cacheEnabled && this.cache.has(key)) {
      return this.cache.get(key);
    }
    
    try {
      // 从KV存储读取
      const value = await this.namespace.get(key);
      
      // 更新缓存
      if (this.cacheEnabled && value !== null) {
        this.cache.set(key, value);
      }
      
      return value;
    } catch (error) {
      console.error(`KV读取错误: ${error.message}`);
      return null;
    }
  }

  /**
   * 写入值到KV存储
   * @param {string} key - 键
   * @param {string} value - 值
   * @param {Object} options - 可选参数，如过期时间
   * @returns {Promise<boolean>} - 操作是否成功
   */
  async set(key, value, options = {}) {
    try {
      // 写入KV存储
      await this.namespace.put(key, value, options);
      
      // 更新缓存
      if (this.cacheEnabled) {
        this.cache.set(key, value);
      }
      
      return true;
    } catch (error) {
      console.error(`KV写入错误: ${error.message}`);
      return false;
    }
  }

  /**
   * 从KV存储删除键
   * @param {string} key - 要删除的键
   * @returns {Promise<boolean>} - 操作是否成功
   */
  async delete(key) {
    try {
      // 从KV存储删除
      await this.namespace.delete(key);
      
      // 从缓存中移除
      if (this.cacheEnabled) {
        this.cache.delete(key);
      }
      
      return true;
    } catch (error) {
      console.error(`KV删除错误: ${error.message}`);
      return false;
    }
  }

  /**
   * 列出KV存储中的键
   * @param {Object} options - 列表选项，如前缀过滤器
   * @returns {Promise<Array>} - 键列表
   */
  async list(options = {}) {
    try {
      const list = await this.namespace.list(options);
      return list.keys;
    } catch (error) {
      console.error(`KV列表错误: ${error.message}`);
      return [];
    }
  }

  /**
   * 清空缓存
   */
  clearCache() {
    this.cache.clear();
  }

  /**
   * 启用或禁用缓存
   * @param {boolean} enabled - 是否启用缓存
   */
  setCacheEnabled(enabled) {
    this.cacheEnabled = enabled;
    if (!enabled) {
      this.clearCache();
    }
  }
}

/**
 * 为WASM模块创建KV函数接口
 * @param {KVHelpers} kvHelpers - KV辅助类实例
 * @returns {Object} - 提供给WASM的KV操作函数
 */
function createKVInterface(kvHelpers) {
  return {
    /**
     * 同步获取KV值（仅限已缓存值）
     * @param {string} key - 键
     * @returns {string|null} - 值或null
     */
    get: (key) => {
      if (kvHelpers.cache.has(key)) {
        return kvHelpers.cache.get(key);
      }
      return null;
    },
    
    /**
     * 同步设置KV值（实际是异步操作，但返回成功）
     * @param {string} key - 键
     * @param {string} value - 值
     * @returns {boolean} - 总是返回true
     */
    set: (key, value) => {
      // 添加到缓存
      kvHelpers.cache.set(key, value);
      // 异步写入KV
      kvHelpers.set(key, value).catch(err => {
        console.error(`异步KV写入错误: ${err.message}`);
      });
      return true;
    }
  };
}

/**
 * 注册KV函数到WASM模块
 * @param {Object} wasmInstance - WASM实例
 * @param {KVHelpers} kvHelpers - KV辅助类实例
 */
function registerKVFunctionsToWasm(wasmInstance, kvHelpers) {
  if (wasmInstance && wasmInstance.exports && 
      typeof wasmInstance.exports.registerKVFunctions === 'function') {
    const kvInterface = createKVInterface(kvHelpers);
    wasmInstance.exports.registerKVFunctions(kvInterface);
    console.log('KV函数已注册到WASM模块');
  } else {
    console.warn('无法注册KV函数：WASM模块未正确导出registerKVFunctions');
  }
}

// 导出函数和类
export { KVHelpers, createKVInterface, registerKVFunctionsToWasm }; 