@echo off
REM 部署到Cloudflare Workers的脚本 (Windows版)
echo ==== 部署AList WASM到Cloudflare Workers ====

REM 检查是否安装了wrangler
where wrangler >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo 错误：未找到wrangler命令。请先安装Cloudflare Wrangler CLI工具：
    echo npm install -g wrangler
    exit /b 1
)

REM 确保dist目录存在
if not exist dist mkdir dist

REM 编译WASM
echo 编译WASM...
set GOOS=js
set GOARCH=wasm
go build -o dist\main.wasm wasm.go

REM 复制JavaScript文件到dist目录
echo 复制JS文件到dist目录...
copy /Y worker.js dist\
copy /Y memory_storage.js dist\
copy /Y wrangler.toml dist\
for /f "tokens=*" %%i in ('go env GOROOT') do set GOROOT=%%i
copy /Y "%GOROOT%\misc\wasm\wasm_exec.js" dist\

REM 使用base64编码WASM文件并替换worker.js中的占位符
echo 编码WASM文件并更新Worker脚本...
certutil -encode dist\main.wasm dist\main.wasm.b64 >nul
powershell -Command "$content = Get-Content dist\main.wasm.b64 | Select-Object -Skip 1 | Select-Object -SkipLast 1; $content = $content -join ''; $workerJs = Get-Content dist\worker.js; $workerJs = $workerJs -replace '{{ WASM_BINARY }}', $content; Set-Content dist\worker.js $workerJs"
del dist\main.wasm.b64

REM 如果指定了域名，则更新wrangler.toml
if not "%~1"=="" (
    echo 更新wrangler.toml配置...
    powershell -Command "(Get-Content dist\wrangler.toml) -replace 'your-domain.com', '%~1' | Set-Content dist\wrangler.toml"
)

REM 部署到Cloudflare Workers
echo 部署到Cloudflare Workers...
cd dist && wrangler publish

echo ==== 部署完成 ==== 