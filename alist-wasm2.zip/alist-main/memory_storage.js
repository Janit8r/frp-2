/**
 * memory_storage.js
 * 内存存储实现，替代Cloudflare KV
 * 注意：此实现仅在Worker运行期间保持数据，不提供持久化存储
 */

/**
 * 内存存储类
 * 提供简单的内存键值存储功能
 */
class MemoryStorage {
  /**
   * 创建MemoryStorage实例
   */
  constructor() {
    this.store = new Map();
    this.initializeDefaultData();
    console.log('内存存储已初始化');
  }

  /**
   * 初始化默认数据
   * 预填充一些基本数据，用于演示
   */
  initializeDefaultData() {
    // 示例用户
    this.set('user:admin', JSON.stringify({
      id: 1,
      username: 'admin',
      password: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', // sha256('admin')
      base_path: '/',
      role: 2,
      disabled: false,
      permission: 767
    }));

    // 系统设置
    this.set('settings:public', JSON.stringify({
      site_title: 'AList WASM Edition',
      allow_registration: false,
      default_page_size: 30,
      version: '1.0.0-wasm'
    }));

    // 测试目录内容
    this.set('fs:/', JSON.stringify({
      content: [
        {
          name: 'Documents',
          is_dir: true,
          size: 0,
          modified: new Date().toISOString()
        },
        {
          name: 'Images',
          is_dir: true,
          size: 0,
          modified: new Date().toISOString()
        },
        {
          name: 'README.txt',
          is_dir: false,
          size: 1024,
          modified: new Date().toISOString()
        }
      ],
      total: 3,
      readme: 'Welcome to AList WASM Edition',
      write: false,
      provider: 'memory'
    }));

    // Images目录内容
    this.set('fs:/Images', JSON.stringify({
      content: [
        {
          name: 'sample.jpg',
          is_dir: false,
          size: 102400,
          modified: new Date().toISOString()
        },
        {
          name: 'logo.png',
          is_dir: false,
          size: 51200,
          modified: new Date().toISOString()
        }
      ],
      total: 2,
      readme: '',
      write: false,
      provider: 'memory'
    }));

    // Documents目录内容
    this.set('fs:/Documents', JSON.stringify({
      content: [
        {
          name: 'report.pdf',
          is_dir: false,
          size: 204800,
          modified: new Date().toISOString()
        },
        {
          name: 'notes.txt',
          is_dir: false,
          size: 2048,
          modified: new Date().toISOString()
        }
      ],
      total: 2,
      readme: '',
      write: false,
      provider: 'memory'
    }));
  }

  /**
   * 从存储获取值
   * @param {string} key - 要获取的键
   * @returns {string|null} - 存储的值或null
   */
  get(key) {
    return this.store.has(key) ? this.store.get(key) : null;
  }

  /**
   * 将值存储到内存
   * @param {string} key - 键
   * @param {string} value - 值
   * @returns {boolean} - 操作是否成功
   */
  set(key, value) {
    try {
      this.store.set(key, value);
      return true;
    } catch (error) {
      console.error(`内存存储错误: ${error.message}`);
      return false;
    }
  }

  /**
   * 从存储中删除键
   * @param {string} key - 要删除的键
   * @returns {boolean} - 操作是否成功
   */
  delete(key) {
    try {
      return this.store.delete(key);
    } catch (error) {
      console.error(`内存存储删除错误: ${error.message}`);
      return false;
    }
  }

  /**
   * 列出所有键
   * @param {string} prefix - 可选的前缀过滤器
   * @returns {Array<string>} - 键列表
   */
  list(prefix = '') {
    try {
      const keys = [];
      for (const key of this.store.keys()) {
        if (prefix === '' || key.startsWith(prefix)) {
          keys.push(key);
        }
      }
      return keys;
    } catch (error) {
      console.error(`内存存储列表错误: ${error.message}`);
      return [];
    }
  }

  /**
   * 清空存储
   */
  clear() {
    try {
      this.store.clear();
      return true;
    } catch (error) {
      console.error(`内存存储清空错误: ${error.message}`);
      return false;
    }
  }
}

// 导出内存存储类
export { MemoryStorage }; 