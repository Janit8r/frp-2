#!/bin/bash

# 部署到Cloudflare Workers的脚本
echo "==== 部署AList WASM到Cloudflare Workers ===="

# 检查是否安装了wrangler
if ! command -v wrangler &> /dev/null; then
    echo "错误：未找到wrangler命令。请先安装Cloudflare Wrangler CLI工具："
    echo "npm install -g wrangler"
    exit 1
fi

# 确保dist目录存在
mkdir -p dist

# 编译WASM
echo "编译WASM..."
GOOS=js GOARCH=wasm go build -o dist/main.wasm wasm.go

# 复制JavaScript文件到dist目录
echo "复制JS文件到dist目录..."
cp worker.js dist/
cp memory_storage.js dist/
cp wrangler.toml dist/
cp $(go env GOROOT)/misc/wasm/wasm_exec.js dist/

# 使用base64编码WASM文件并替换worker.js中的占位符
echo "编码WASM文件并更新Worker脚本..."
WASM_BASE64=$(base64 -w 0 dist/main.wasm)
sed -i "s|{{ WASM_BINARY }}|${WASM_BASE64}|" dist/worker.js

# 如果指定了KV命名空间ID，则更新wrangler.toml
if [ ! -z "$1" ]; then
    echo "更新wrangler.toml配置..." 
    sed -i "s|your-domain.com|$2|g" dist/wrangler.toml
fi

# 部署到Cloudflare Workers
echo "部署到Cloudflare Workers..."
cd dist && wrangler publish

echo "==== 部署完成 ====" 