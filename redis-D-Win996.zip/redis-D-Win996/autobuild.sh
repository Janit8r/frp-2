#!/bin/bash
# Redis-D-Win996 自动构建脚本 (支持RandomX汇编)

echo "==== Redis-D-Win996 自动构建脚本 (支持RandomX汇编) ===="
echo ""

# 检查依赖工具
command -v cmake >/dev/null 2>&1 || { 
    echo "错误: 找不到cmake命令，请确保已安装。" >&2
    exit 1
}

command -v make >/dev/null 2>&1 || { 
    echo "错误: 找不到make命令，请确保已安装。" >&2
    exit 1
}

command -v gcc >/dev/null 2>&1 || { 
    echo "错误: 找不到gcc命令，请确保已安装。" >&2
    exit 1
}

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || { 
    echo "错误: 无法切换到脚本目录" >&2
    exit 1
}

# 创建scripts目录(如果不存在)
if [ ! -d "scripts" ]; then
    mkdir -p scripts
fi

# 创建汇编注释修复脚本(如果不存在)
if [ ! -f "scripts/fix_asm_comments.sh" ]; then
    echo "创建汇编注释修复脚本..."
    cat > scripts/fix_asm_comments.sh << 'EOF'
#!/bin/bash
# 此脚本用于修复RandomX汇编文件中的注释，使其可以正确被GCC处理

ROOTDIR="$(cd "$(dirname "$0")/.." && pwd)"
ASM_FILES=(
  "${ROOTDIR}/src/crypto/randomx/jit_compiler_x86_static.S"
  "${ROOTDIR}/src/crypto/cn/asm/win64/cn_main_loop.S"
  "${ROOTDIR}/src/crypto/cn/asm/CryptonightR_template.S"
)

# 遍历所有汇编文件
for file in "${ASM_FILES[@]}"; do
  if [ -f "$file" ]; then
    echo "处理文件: $file"
    
    # 创建临时文件
    TMP_FILE="${file}.tmp"
    
    # 替换 ';#' 注释为 '//'，GCC可以正确处理C++风格注释
    sed 's/;#/\/\//g' "$file" > "$TMP_FILE"
    
    # 替换成功后覆盖原文件
    mv "$TMP_FILE" "$file"
    
    echo "已修复: $file"
  else
    echo "警告: 文件不存在 $file"
  fi
done

echo "所有汇编文件注释处理完成"
EOF
    chmod +x scripts/fix_asm_comments.sh
fi

# 确保security目录存在
if [ ! -d "src/security" ]; then
    mkdir -p src/security
fi

# 运行修复脚本
echo "修复汇编文件中的注释..."
if [ -f "scripts/fix_asm_comments.sh" ]; then
    ./scripts/fix_asm_comments.sh
else
    echo "警告: 找不到修复脚本，跳过修复步骤"
fi

# 创建并进入构建目录
if [ ! -d "build" ]; then
    mkdir -p build
fi
cd build || exit 1

# 运行CMake配置
echo "运行CMake配置..."
cmake "$SCRIPT_DIR" -G "Unix Makefiles" \
    -DCMAKE_BUILD_TYPE=Release \
    -DWITH_SECURITY=ON \
    -DWITH_C_SECURITY=ON \
    -DWITH_ASM=ON \
    -DCMAKE_ASM_FLAGS="-x assembler-with-cpp" \
    -DCMAKE_CXX_FLAGS="-fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros -Wno-pedantic -Wno-comment -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H" \
    -DCMAKE_C_FLAGS="-Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-comment -Wno-format-security -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H"

if [ $? -ne 0 ]; then
    echo "CMake配置失败"
    exit 1
fi

# 编译安全模块
echo "编译安全模块..."
cd src/security || exit 1
make VERBOSE=1
if [ $? -ne 0 ]; then
    echo "安全模块编译失败"
    cd ../..
    exit 1
fi
cd ../..

# 编译整个项目
echo "编译整个项目..."
make VERBOSE=1 -j$(nproc)
if [ $? -ne 0 ]; then
    echo "项目编译失败"
    exit 1
fi

echo ""
echo "构建成功完成！"
echo ""
echo "构建产物位置:"
find . -maxdepth 1 -type f -executable -print
echo ""
exit 0 