@echo off
REM 这个脚本用于在Windows环境中通过MSYS2执行build.yml中的命令

echo ==== 执行build.yml中的构建命令 ====
echo.

REM 检查是否安装了MSYS2
where bash.exe >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo 错误: 未找到bash.exe，请确保已安装MSYS2并将其bin目录添加到PATH中
    echo 您可以从以下地址下载MSYS2: https://www.msys2.org/
    exit /b 1
)

REM 获取当前脚本绝对路径
set SCRIPT_DIR=%~dp0
set SCRIPT_DIR=%SCRIPT_DIR:~0,-1%

REM 确保创建一个run_in_msys2.sh作为中间脚本
echo #!/bin/bash > "%SCRIPT_DIR%\run_in_msys2.sh"
echo cd "%SCRIPT_DIR:\=/%" >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo if [ -f "run_build_yml.sh" ]; then >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo   chmod +x run_build_yml.sh >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo   ./run_build_yml.sh >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo else >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo   echo "Error: run_build_yml.sh not found!" >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo   exit 1 >> "%SCRIPT_DIR%\run_in_msys2.sh"
echo fi >> "%SCRIPT_DIR%\run_in_msys2.sh"

REM 检查MSYS2路径
REM 尝试常见的MSYS2安装位置
set MSYS2_PATHS=C:\msys64 C:\msys2 C:\tools\msys64 C:\tools\msys2

for %%p in (%MSYS2_PATHS%) do (
    if exist "%%p\usr\bin\bash.exe" (
        echo 使用MSYS2路径: %%p
        "%%p\usr\bin\bash.exe" --login -i "%SCRIPT_DIR%\run_in_msys2.sh"
        goto :cleanup
    )
)

REM 如果没有找到MSYS2安装，尝试使用PATH中的bash
echo 未找到MSYS2安装目录，尝试使用PATH中的bash...
bash --login -i "%SCRIPT_DIR%\run_in_msys2.sh"

:cleanup
REM 清理临时脚本
del "%SCRIPT_DIR%\run_in_msys2.sh"

echo.
if %ERRORLEVEL% equ 0 (
    echo 构建成功完成!
) else (
    echo 构建失败，错误代码: %ERRORLEVEL%
)
exit /b %ERRORLEVEL% 