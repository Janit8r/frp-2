#!/bin/bash
# 这个脚本用于在本地MSYS2环境中执行build.yml中的命令

echo "==== 执行build.yml中的构建命令 ===="
echo ""

# 检查是否在MSYS2环境中运行
if [[ "$(uname -o)" != "Msys" ]]; then
  echo "错误: 这个脚本需要在MSYS2环境中运行!"
  echo "请使用MSYS2的MINGW64终端运行此脚本。"
  exit 1
fi

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# 执行build.yml中的命令
echo "修复汇编文件中的注释..."
if [ -f "scripts/fix_asm_comments.sh" ]; then
  chmod +x scripts/fix_asm_comments.sh
  ./scripts/fix_asm_comments.sh
else
  echo "创建临时修复脚本..."
  for file in src/crypto/randomx/jit_compiler_x86_static.S src/crypto/cn/asm/win64/cn_main_loop.S src/crypto/cn/asm/CryptonightR_template.S; do
    if [ -f "$file" ]; then
      echo "修复文件: $file"
      sed -i 's/;#/\/\//g' "$file"
    fi
  done
fi

# 确保安全模块目录存在
mkdir -p src/security

# 配置CMake
echo "配置CMake..."
mkdir -p build
cd build || exit 1

# 检查GITHUB_WORKSPACE环境变量是否存在，如果不存在则使用当前目录
if [ -n "$GITHUB_WORKSPACE" ]; then
  SOURCE_DIR="$GITHUB_WORKSPACE"
else
  SOURCE_DIR="$(cd .. && pwd)"
fi

echo "使用源代码目录: $SOURCE_DIR"

cmake "$SOURCE_DIR" -G "MinGW Makefiles" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_FLAGS='-static -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-narrowing -Wno-format-security -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H' \
  -DCMAKE_CXX_FLAGS='-static -fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H' \
  -DCMAKE_ASM_FLAGS='-x assembler-with-cpp' \
  -DBUILD_SHARED_LIBS=OFF \
  -DHWLOC_INCLUDE_DIRS=/mingw64/include \
  -DHWLOC_LIBRARIES=/mingw64/lib/libhwloc.a \
  -DWITH_SECURITY=ON \
  -DWITH_C_SECURITY=ON \
  -DWITH_ASM=ON

if [ $? -ne 0 ]; then
  echo "CMake配置失败"
  exit 1
fi

# 编译安全模块
echo "编译安全模块..."
cd src/security || exit 1
mingw32-make VERBOSE=1
if [ $? -ne 0 ]; then
  echo "安全模块编译失败"
  cd ../..
  exit 1
fi
cd ../..

# 准备RandomX汇编编译
echo "准备RandomX汇编编译..."
cmake "$SOURCE_DIR" -G "MinGW Makefiles" \
  -DCMAKE_C_FLAGS='-static -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-narrowing -Wno-format-security -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H' \
  -DCMAKE_CXX_FLAGS='-static -fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H' \
  -DCMAKE_ASM_FLAGS='-x assembler-with-cpp' \
  -DBUILD_SHARED_LIBS=OFF \
  -DHWLOC_INCLUDE_DIRS=/mingw64/include \
  -DHWLOC_LIBRARIES=/mingw64/lib/libhwloc.a \
  -DWITH_SECURITY=ON \
  -DWITH_C_SECURITY=ON \
  -DWITH_ASM=ON

if [ $? -ne 0 ]; then
  echo "RandomX ASM配置失败"
  exit 1
fi

# 编译整个项目
echo "编译整个项目..."
mingw32-make VERBOSE=1 -j$(nproc)

if [ $? -ne 0 ]; then
  echo "项目编译失败"
  exit 1
fi

echo ""
echo "构建成功完成！"
echo ""
echo "构建产物位置:"
find . -maxdepth 1 -name "*.exe" -type f | sort
echo ""
exit 0 