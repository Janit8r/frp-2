import pefile
import random
import string

def random_dll_name():
    return ''.join(random.choices(string.ascii_uppercase, k=4)) + '.dll'

pe = pefile.PE('redis.exe')
pe.DOS_HEADER.e_res = [random.randint(0,0xFFFF) for _ in range(4)]

new_import = pefile.DIRECTORY_ENTRY_IMPORT()
new_import.dll = random_dll_name().encode()
new_import.imports = [pefile.ImportEntry(
    name=bytes([random.randint(0x41,0x5A) for _ in range(8)]),
    ordinal=random.randint(1,255)
) for _ in range(5)]
pe.DIRECTORY_ENTRY_IMPORT.append(new_import)

pe.write('redis_obf.exe')