#pragma once

// 声明汇编文件中的函数
extern "C" {
    // 从TEB中获取PEB地址
    void* GetPEB();
    
    // 设置系统调用号
    void AmmunitionPrepare(unsigned short systemCall);
    
    // 保存系统调用指令地址
    unsigned long GunPrepare(void* syscallAdr);
    
    // 执行系统调用
    long long GunFire();
} 