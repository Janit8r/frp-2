.data
    systemCall WORD 000h
    syscallAddr QWORD 0h

.code
    ; 从TEB中获取PEB地址
    GetPEB proc
        mov rax, gs:[30h]         ; 从GS段寄存器读取TEB地址
        mov rax, [rax + 60h]      ; 从TEB中获取PEB
        ret
    GetPEB endp

    ; 设置系统调用号
    AmmunitionPrepare proc
        mov systemCall, cx
        ret
    AmmunitionPrepare endp

    ; 保存系统调用指令地址
    GunPrepare proc
        mov rax, syscallAddr
        test rax, rax
        jnz THEEND
        mov syscallAddr, rcx
        xor rax, rax
    THEEND:
        ret
    GunPrepare endp

    ; 执行系统调用
    GunFire proc
        mov r10, rcx              ; 第二个参数移动到r10，符合x64调用约定
        mov eax, 0                ; 清零EAX
        mov ax, systemCall        ; 设置系统调用号
        test ax, ax
        jz GunRuined
        jmp qword ptr [syscallAddr] ; 使用中括号，通过指针跳转
    GunFire endp

    ; 系统调用失败
    GunRuined proc
        mov rax, 0FFFFFFFFC0000001h ; 返回STATUS_UNSUCCESSFUL
        ret
    GunRuined endp

end 