# 反调试与API解析功能

此模块为redis-D-Win996项目提供了高级反调试和动态API解析功能，帮助应用程序避免被分析和防止API挂钩。

## 功能列表

1. **动态API解析**
   - 使用哈希混淆API名称，防止静态分析
   - 基于PEB的DLL发现，避免使用标准LoadLibrary函数

2. **系统调用解脱技术**
   - 地狱之门 (Hell's Gate) - 直接获取系统调用号
   - 光环之门 (Halo's Gate) - 处理已修改的系统调用入口点
   - 塔塔鲁斯之门 (Tartarus Gate) - 处理完全挂钩的API

3. **反调试技术**
   - 基于PEB的调试器检测
   - NtGlobalFlag检测
   - 异常检测 (int 3指令)
   - IsDebuggerPresent API验证

## 核心文件

- `structs.h` - Windows内部结构体定义
- `syscalls.asm` - 汇编级系统调用实现
- `unhooker.cpp/h` - 系统调用解脱和API哈希实现
- `api_resolver.cpp/h` - 高级API管理和系统调用包装

## 使用方法

```cpp
// 初始化API解析器（在程序启动时）
xmrig::ApiResolver::GetInstance();

// 检查是否存在调试器
if (xmrig::ApiResolver::GetInstance()->IsDebugged()) {
    // 调试器存在，可以选择退出或采取其他操作
}

// 使用系统调用执行内存分配
PVOID baseAddress = NULL;
SIZE_T regionSize = 0x1000;
NTSTATUS status = xmrig::ApiResolver::GetInstance()->NtAllocateVirtualMemory(
    NtCurrentProcess(),  // 当前进程句柄 
    &baseAddress,        // 内存地址
    0,                   // ZeroBits
    &regionSize,         // 区域大小
    MEM_COMMIT | MEM_RESERVE, // 分配类型
    PAGE_READWRITE       // 保护类型
);
```

## 技术实现细节

### 哈希混淆

API名称和DLL名称使用自定义哈希算法转换为数字标识符，避免明文字符串在二进制文件中出现。

### 系统调用执行

1. **准备阶段**：
   - 查找目标API（如NtAllocateVirtualMemory）
   - 使用地狱之门/光环之门/塔塔鲁斯之门技术解析系统调用号
   - 设置系统调用号到共享内存

2. **执行阶段**：
   - 使用优化的汇编代码执行系统调用
   - 绕过可能存在的用户模式钩子

### 内存保护

此框架在执行关键操作时（如内存分配和保护更改）直接使用系统调用，从而绕过可能被挂钩的Windows API。 