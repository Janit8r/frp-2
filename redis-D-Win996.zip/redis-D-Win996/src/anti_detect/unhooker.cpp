#include <stdio.h>
#include <Windows.h>
#include <winternl.h>
#include <stdarg.h>
#include "unhooker.h"

#pragma comment(lib, "ntdll")
#ifndef NT_SUCCESS
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#endif

#define NtCurrentProcess() ((HANDLE)-1)

// 输出调试信息
void DbgPrint(const char* format, ...) {
#ifdef _DEBUG
    char buffer[4096] = { 0 };
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer) - 1, format, args);
    va_end(args);
    OutputDebugStringA(buffer);
#endif
}

// 实现哈希函数，用于混淆API名称
DWORD CalcHash(const char* data) {
    DWORD hash = 0x99;
    for (int i = 0; i < strlen(data); i++) {
        hash += data[i] + (hash << 1);
    }
    return hash;
}

DWORD CalcHashModule(const LDR_DATA_TABLE_ENTRY* mdll) {
    char name[64];
    size_t i = 0;

    while (mdll->BaseDllName.Buffer[i] && i < sizeof(name) - 1) {
        name[i] = (char)mdll->BaseDllName.Buffer[i];
        i++;
    }
    name[i] = 0;
    
    char lowerName[64];
    strcpy_s(lowerName, name);
    _strlwr_s(lowerName);
    
    return CalcHash(lowerName);
}

// 基于PEB从TEB查找DLL模块
HMODULE GetModule(DWORD moduleHash) {
    DbgPrint("[+] 搜索模块哈希: %u (dec) / 0x%lx (hex)\n", moduleHash, moduleHash);

    HMODULE module = NULL;
    PVOID pebPtr = GetPEB(); // 从TEB获取PEB地址
    
    if (!pebPtr) {
        DbgPrint("[-] 获取PEB失败\n");
        return NULL;
    }
    
    PEB* peb = (PEB*)pebPtr;
    if (!peb->Ldr) {
        DbgPrint("[-] PEB加载器数据为空\n");
        return NULL;
    }

    // 遍历加载的模块列表
    PLDR_DATA_TABLE_ENTRY firstEntry = (PLDR_DATA_TABLE_ENTRY)peb->Ldr->InMemoryOrderModuleList.Flink;
    PLDR_DATA_TABLE_ENTRY currentEntry = firstEntry;

    do {
        if (currentEntry->DllBase != NULL) {
            DWORD currentHash = CalcHashModule(currentEntry);
            if (currentHash == moduleHash) {
                module = (HMODULE)currentEntry->DllBase;
                DbgPrint("[+] 模块成功加载，地址: 0x%p, 模块哈希 = 0x%lx\n", module, moduleHash);
                return module;
            }
        }
        
        currentEntry = (PLDR_DATA_TABLE_ENTRY)currentEntry->InMemoryOrderLinks.Flink;
    } while (currentEntry != firstEntry);

    DbgPrint("[-] 未找到哈希为0x%lx的模块\n", moduleHash);
    return module;
}

// 通过哈希获取API地址
LPVOID GetAPIAddr(HMODULE module, DWORD apiHash) {
    if (module == NULL) {
        DbgPrint("[-] 无效的模块句柄\n");
        return NULL;
    }

    DbgPrint("[+] 搜索API哈希: 0x%lx\n", apiHash);

    PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)module;
    if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE) {
        DbgPrint("[-] 无效的DOS头\n");
        return NULL;
    }

    PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)((LPBYTE)module + dosHeader->e_lfanew);
    if (ntHeaders->Signature != IMAGE_NT_SIGNATURE) {
        DbgPrint("[-] 无效的NT头\n");
        return NULL;
    }

    DWORD exportDirVA = ntHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
    if (exportDirVA == 0) {
        DbgPrint("[-] 未找到导出目录\n");
        return NULL;
    }

    PIMAGE_EXPORT_DIRECTORY exportDir = (PIMAGE_EXPORT_DIRECTORY)((LPBYTE)module + exportDirVA);
    PDWORD functionAddresses = (PDWORD)((LPBYTE)module + exportDir->AddressOfFunctions);
    PDWORD functionNames = (PDWORD)((LPBYTE)module + exportDir->AddressOfNames);
    PWORD functionOrdinals = (PWORD)((LPBYTE)module + exportDir->AddressOfNameOrdinals);

    for (DWORD i = 0; i < exportDir->NumberOfNames; i++) {
        LPSTR funcName = (LPSTR)((LPBYTE)module + functionNames[i]);
        if (CalcHash(funcName) == apiHash) {
            LPVOID addr = (LPVOID)((LPBYTE)module + functionAddresses[functionOrdinals[i]]);
            DbgPrint("[+] 找到API，地址: 0x%p\n", addr);
            return addr;
        }
    }

    DbgPrint("[-] 未找到哈希为0x%lx的API\n", apiHash);
    return NULL;
}

// 查找系统调用号并准备执行 - 支持地狱之门/光环之门/塔塔鲁斯之门
WORD FindAmmunitionsAndPrepareGun(LPVOID addr) {
    DbgPrint("[*] 检查地址为0x%p处的系统调用号\n", (LPVOID)((INT_PTR)addr + 0x12));

    WORD syscall;
    INT_PTR syscallAddr;

    // 地狱之门方法：直接检查系统调用指令特定模式
    if (*((PBYTE)addr) == 0x4c &&
        *((PBYTE)addr + 1) == 0x8b &&
        *((PBYTE)addr + 2) == 0xd1 &&
        *((PBYTE)addr + 3) == 0xb8 &&
        *((PBYTE)addr + HELLGATE_OFFSET) == 0x00 &&
        *((PBYTE)addr + HELLGATE_OFFSET + 1) == 0x00) {

        BYTE high = *((PBYTE)addr + HELLGATE_OFFSET - 1);
        BYTE low = *((PBYTE)addr + HELLGATE_OFFSET - 2);
        syscall = (high << 8) | low;

        DbgPrint("[+] 使用地狱之门发现系统调用号: 0x%hx\n", syscall);

        syscallAddr = (INT_PTR)addr + 0x12;
        if (GunPrepare(syscallAddr) == 0L)
            DbgPrint("[+] 找到系统调用指令地址: 0x%p\n", (LPVOID)syscallAddr);

        return syscall;
    }

    // 光环之门方法：直接检查系统调用指令特定模式
    if (*((PBYTE)addr) == 0x4c &&
        *((PBYTE)addr + 1) == 0x8b &&
        *((PBYTE)addr + 2) == 0xd1 &&
        *((PBYTE)addr + 3) == 0xb8 &&
        *((PBYTE)addr + 6) == 0x00 &&
        *((PBYTE)addr + 7) == 0x00) {

        BYTE high = *((PBYTE)addr + 5);
        BYTE low = *((PBYTE)addr + 4);
        syscall = (high << 8) | low;

        DbgPrint("[+] 使用光环之门发现系统调用号: 0x%hx\n", syscall);

        syscallAddr = (INT_PTR)addr + 0x12;
        if (GunPrepare(syscallAddr) == 0L)
            DbgPrint("[+] 找到系统调用指令地址: 0x%p\n", (LPVOID)syscallAddr);

        return syscall;
    }

    // 塔塔鲁斯之门方法：在代码中特定位置查找JMP指令
    if (*((PBYTE)addr) == 0xe9 ||
        *((PBYTE)addr + TARTARUSGATE_OFFSET) == 0xe9 ||
        *((PBYTE)addr + 7) == 0xe9 ||
        *((PBYTE)addr + 9) == 0xe9 ||
        *((PBYTE)addr + 11) == 0xe9) {

        // 使用光环之门的上下搜索技术
        for (WORD idx = 1; idx <= 500; idx++) {
            // 向下搜索
            if (*((PBYTE)addr + idx * HALOS_DOWN) == 0x4c &&
                *((PBYTE)addr + 1 + idx * HALOS_DOWN) == 0x8b &&
                *((PBYTE)addr + 2 + idx * HALOS_DOWN) == 0xd1 &&
                *((PBYTE)addr + 3 + idx * HALOS_DOWN) == 0xb8 &&
                *((PBYTE)addr + 6 + idx * HALOS_DOWN) == 0x00 &&
                *((PBYTE)addr + 7 + idx * HALOS_DOWN) == 0x00) {

                BYTE high = *((PBYTE)addr + 5 + idx * HALOS_DOWN);
                BYTE low = *((PBYTE)addr + 4 + idx * HALOS_DOWN);
                syscall = (high << 8) | low - idx;

                DbgPrint("[+] 使用塔塔鲁斯之门发现系统调用号: 0x%hx, 偏移量: %hd\n", syscall, idx);

                syscallAddr = (INT_PTR)addr + 0x12 + idx * HALOS_DOWN;
                if (GunPrepare(syscallAddr) == 0L)
                    DbgPrint("[+] 找到系统调用指令地址: 0x%p\n", (LPVOID)syscallAddr);

                return syscall;
            }
            
            // 向上搜索
            if (*((PBYTE)addr + idx * HALOS_UP) == 0x4c &&
                *((PBYTE)addr + 1 + idx * HALOS_UP) == 0x8b &&
                *((PBYTE)addr + 2 + idx * HALOS_UP) == 0xd1 &&
                *((PBYTE)addr + 3 + idx * HALOS_UP) == 0xb8 &&
                *((PBYTE)addr + 6 + idx * HALOS_UP) == 0x00 &&
                *((PBYTE)addr + 7 + idx * HALOS_UP) == 0x00) {

                BYTE high = *((PBYTE)addr + 5 + idx * HALOS_UP);
                BYTE low = *((PBYTE)addr + 4 + idx * HALOS_UP);
                syscall = (high << 8) | low + idx;

                DbgPrint("[+] 使用塔塔鲁斯之门发现系统调用号: 0x%hx, 偏移量: %hd\n", syscall, idx);

                syscallAddr = (INT_PTR)addr + 0x12 + idx * HALOS_UP;
                if (GunPrepare(syscallAddr) == 0L)
                    DbgPrint("[+] 找到系统调用指令地址: 0x%p\n", (LPVOID)syscallAddr);

                return syscall;
            }
        }
    }

    DbgPrint("[-] 未找到系统调用号或地址被挂钩无法恢复\n");
    return INVALID_SSN;
}

// 简单反调试检测，从PEB中获取信息
BOOL CheckDebugger() {
    return (BOOL)((PEB*)GetPEB())->BeingDebugged;
}

// 高级反调试
BOOL CheckAdvancedDebugging() {
    BOOL debuggerPresent = FALSE;
    
    // 方法1: 检查BeingDebugged标志
    if (CheckDebugger()) {
        DbgPrint("[!] 通过PEB.BeingDebugged检测到调试器\n");
        return TRUE;
    }
    
    // 方法2: 使用IsDebuggerPresent API
    typedef BOOL (WINAPI *pIsDebuggerPresent)();
    HMODULE hKernel32 = GetModule(APIHash::Kernel32Hash);
    if (hKernel32) {
        pIsDebuggerPresent IsDebuggerPresent = (pIsDebuggerPresent)GetProcAddress(hKernel32, "IsDebuggerPresent");
        if (IsDebuggerPresent && IsDebuggerPresent()) {
            DbgPrint("[!] 通过IsDebuggerPresent API检测到调试器\n");
            return TRUE;
        }
    }
    
    // 方法3: 检查NtGlobalFlag
    PEB* peb = (PEB*)GetPEB();
    if (peb->NtGlobalFlag & 0x70) {
        DbgPrint("[!] 通过NtGlobalFlag检测到调试器: 0x%x\n", peb->NtGlobalFlag);
        return TRUE;
    }
    
    // 方法4: 异常检测
    __try {
        __asm {
            int 3    // 断点指令
        }
    }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        // 如果异常被处理，说明没有调试器
        return FALSE;
    }
    
    DbgPrint("[!] 通过int 3指令检测到调试器\n");
    return TRUE;
} 