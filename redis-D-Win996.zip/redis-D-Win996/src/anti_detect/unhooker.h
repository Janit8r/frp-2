#pragma once
#include <Windows.h>
#include "structs.h"
#include "asm_exports.h"

#define INVALID_SSN 0xffff
#define HALOS_DOWN 32
#define HALOS_UP -32
#define HELLGATE_OFFSET 8
#define TARTARUSGATE_OFFSET 12

// 外部汇编函数声明
extern "C" {
    VOID AmmunitionPrepare(WORD systemCall);
    ULONG GunPrepare(INT_PTR syscallAdr);
    PVOID GetPEB();
    NTSTATUS GunFire();
}

// 用于查找系统调用号并准备执行
WORD FindAmmunitionsAndPrepareGun(LPVOID addr);

// 哈希函数，用于混淆API名称
DWORD CalcHash(const char* data);
DWORD CalcHashModule(const LDR_DATA_TABLE_ENTRY* mdll);

// 基于PEB从TEB查找DLL模块
HMODULE GetModule(DWORD moduleHash);

// 通过哈希获取API地址
LPVOID GetAPIAddr(HMODULE module, DWORD apiHash);

// 反调试检测
BOOL CheckDebugger();
BOOL CheckAdvancedDebugging();

// 实用函数
void DbgPrint(const char* format, ...);

// 定义常用API和模块的哈希值
namespace APIHash {
    const DWORD NtdllHash = 0x3e8557;
    const DWORD Kernel32Hash = 0x6a4abc5b;
    
    // API哈希值
    const DWORD ZwAllocateVirtualMemory = 0x112da6be2b35;
    const DWORD NtProtectVirtualMemory = 0x59ef896aad4;
    const DWORD NtCreateThreadEx = 0x1f7ecc338;
    const DWORD NtWaitForSingleObject = 0x26a68df;
    const DWORD NtQueryInformationThread = 0x59e9e0b318;
    const DWORD NtClose = 0x1dc1f434;
} 