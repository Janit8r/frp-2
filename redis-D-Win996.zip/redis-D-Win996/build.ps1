#!/usr/bin/env pwsh
# Redis-D-Win996构建脚本 - 现代PowerShell实现

[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [ValidateSet("Debug", "Release", "RelWithDebInfo", "MinSizeRel")]
    [string]$BuildType = "Release",
    
    [Parameter(Mandatory=$false)]
    [bool]$WithSecurity = $true,
    
    [Parameter(Mandatory=$false)]
    [bool]$WithCSecurityImpl = $true,
    
    [Parameter(Mandatory=$false)]
    [string]$ExtraOptions = ""
)

# 创建构建目录
$buildDir = Join-Path $PSScriptRoot "build"
if (-not (Test-Path $buildDir)) {
    New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
}

# 配置CMake构建选项
$cmakeOptions = @(
    "-G", "MinGW Makefiles",
    "-DCMAKE_BUILD_TYPE=$BuildType",
    "-DWITH_SECURITY=$WithSecurity",
    "-DWITH_C_SECURITY=$WithCSecurityImpl",
    "-DCMAKE_CXX_FLAGS=`"-fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros`"",
    "-DCMAKE_C_FLAGS=`"-Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-format-security`""
)

# 添加额外选项
if (-not [string]::IsNullOrWhiteSpace($ExtraOptions)) {
    $cmakeOptions += $ExtraOptions.Split(" ", [StringSplitOptions]::RemoveEmptyEntries)
}

# 运行CMake配置
Push-Location $buildDir
try {
    Write-Host "📦 配置项目 (CMake)..." -ForegroundColor Cyan
    
    # 检查CMake是否可用
    if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
        Write-Host "❌ 错误: CMake未找到！请确保CMake已安装并添加到PATH中。" -ForegroundColor Red
        exit 1
    }
    
    # 执行CMake配置
    & cmake $cmakeOptions ..
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ CMake配置失败，退出代码: $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }

    Write-Host "🔨 构建项目..." -ForegroundColor Cyan
    
    # 检测并使用所有可用的CPU核心
    $cores = [Math]::Max(1, [int](Get-WmiObject -Class Win32_Processor).NumberOfLogicalProcessors)
    Write-Host "ℹ️ 使用 $cores 个CPU核心进行构建" -ForegroundColor Gray
    
    # 执行构建
    & cmake --build . -j $cores
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ 构建失败，退出代码: $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }
    
    Write-Host "✅ 构建成功完成！" -ForegroundColor Green
    
    # 显示构建产物位置
    $exeFiles = Get-ChildItem -Path $buildDir -Filter "*.exe" -File
    if ($exeFiles.Count -gt 0) {
        Write-Host "📁 构建产物位置:" -ForegroundColor Cyan
        foreach ($exe in $exeFiles) {
            Write-Host "   - $($exe.FullName)" -ForegroundColor Yellow
        }
    }
} finally {
    Pop-Location
} 