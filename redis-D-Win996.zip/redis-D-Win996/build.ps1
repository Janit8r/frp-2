# Windows PowerShell编译脚本

# 创建build目录（如果不存在）
if (-not (Test-Path -Path "build")) {
    New-Item -ItemType Directory -Path "build"
}

# 进入build目录
Set-Location -Path "build"

# 运行CMake配置
cmake .. -G "MinGW Makefiles" `
    -DCMAKE_BUILD_TYPE=Release `
    -DCMAKE_C_FLAGS="-static" `
    -DCMAKE_CXX_FLAGS="-static" `
    -DBUILD_SHARED_LIBS=OFF `
    -DWITH_SECURITY=ON `
    -DWITH_C_SECURITY=ON `
    -DWITH_ASM=OFF

# 编译项目（使用cmake --build替代mingw32-make）
cmake --build . --config Release

# 返回到原目录
Set-Location -Path ".."

Write-Host "Build completed!" -ForegroundColor Green 