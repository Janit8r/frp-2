#!/usr/bin/env pwsh
# 构建脚本 - Windows PowerShell

param (
    [Parameter(Mandatory=$false)]
    [string]$BuildType = "Release",
    
    [Parameter(Mandatory=$false)]
    [bool]$WithSecurity = $true,
    
    [Parameter(Mandatory=$false)]
    [bool]$WithCSecurityImpl = $true,
    
    [Parameter(Mandatory=$false)]
    [string]$ExtraOptions = ""
)

# 创建构建目录
$buildDir = Join-Path $PSScriptRoot "build"
if (-not (Test-Path $buildDir)) {
    New-Item -ItemType Directory -Path $buildDir | Out-Null
}

# 配置CMake构建选项
$cmakeOptions = @(
    "-G", "MinGW Makefiles",
    "-DCMAKE_BUILD_TYPE=$BuildType",
    "-DWITH_SECURITY=$WithSecurity",
    "-DWITH_C_SECURITY=$WithCSecurityImpl",
    "-DCMAKE_CXX_FLAGS=`"-fpermissive -Wno-write-strings -Wno-deprecated`"",
    "-DCMAKE_C_FLAGS=`"-Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-format-security`""
)

# 添加额外选项
if ($ExtraOptions) {
    $cmakeOptions += $ExtraOptions.Split(" ")
}

# 运行CMake配置
Push-Location $buildDir
try {
    Write-Host "Configuring project with CMake..."
    & cmake $cmakeOptions ..
    if ($LASTEXITCODE -ne 0) {
        Write-Error "CMake configuration failed with exit code $LASTEXITCODE"
        exit $LASTEXITCODE
    }

    Write-Host "Building project..."
    & cmake --build .
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Build failed with exit code $LASTEXITCODE"
        exit $LASTEXITCODE
    }
    
    Write-Host "Build completed successfully."
} finally {
    Pop-Location
} 