#!/usr/bin/env pwsh
# 构建脚本 - Windows PowerShell

# 创建build目录
if (-not (Test-Path -Path "build")) {
    New-Item -ItemType Directory -Path "build"
}

# 进入build目录
Set-Location -Path "build"

# 设置gcc环境变量（如果需要）
# $env:PATH = "C:\path\to\gcc\bin;$env:PATH"

# 运行CMake生成Makefiles
& cmake .. -G "MinGW Makefiles" `
    -DCMAKE_C_FLAGS='-static -DUSE_C_IMPLEMENTATION' `
    -DCMAKE_CXX_FLAGS='-static -DUSE_C_IMPLEMENTATION' `
    -DBUILD_SHARED_LIBS=OFF `
    -DWITH_SECURITY=ON `
    -DWITH_C_SECURITY=ON `
    -DWITH_ASM=OFF

# 编译项目
& mingw32-make -j4

# 返回上级目录
Set-Location -Path ".."

Write-Host "Build completed. Executable is in the build directory." 