import os
import re

# 敏感API列表及其DLL
api_map = {
    "RegOpenKeyExW":      ("advapi32", "LSTATUS (WINAPI *)(HKEY, LPCWSTR, DWORD, REGSAM, PHKEY)"),
    "RegQueryValueExW":   ("advapi32", "LSTATUS (WINAPI *)(HKEY, LPCWSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD)"),
    "RegGetValueW":       ("advapi32", "LSTATUS (WINAPI *)(HKEY, LPCWSTR, LPCWSTR, DWORD, LPDWORD, PVOID, LPDWORD)"),
    "CryptGenRandom":     ("advapi32", "BOOL (WINAPI *)(HCRYPTPROV, DWORD, BYTE*)"),
    "CryptAcquireContextW":("advapi32", "BOOL (WINAPI *)(HCRYPTPROV*, LPCWSTR, LPCWSTR, DWORD, DWORD)"),
    "CreateProcessW":     ("kernel32", "BOOL (WINAPI *)(LPCWSTR, LPWSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES, BOOL, DWORD, LPVOID, LPCWSTR, LPSTARTUPINFOW, LPPROCESS_INFORMATION)"),
    "WriteProcessMemory": ("kernel32", "BOOL (WINAPI *)(HANDLE, LPVOID, LPCVOID, SIZE_T, SIZE_T*)"),
    "MiniDumpWriteDump":  ("dbghelp",  "BOOL (WINAPI *)(HANDLE, DWORD, HANDLE, MINIDUMP_TYPE, PMINIDUMP_EXCEPTION_INFORMATION, PMINIDUMP_USER_STREAM_INFORMATION, PMINIDUMP_CALLBACK_INFORMATION)"),
    "socket":             ("ws2_32",   "SOCKET (WINAPI *)(int, int, int)"),
    "connect":            ("ws2_32",   "int (WINAPI *)(SOCKET, const struct sockaddr*, int)"),
    "send":               ("ws2_32",   "int (WINAPI *)(SOCKET, const char*, int, int)"),
    "recv":               ("ws2_32",   "int (WINAPI *)(SOCKET, char*, int, int)"),
    "WSAStartup":         ("ws2_32",   "int (WINAPI *)(WORD, LPWSADATA)"),
    "WSASocketW":         ("ws2_32",   "SOCKET (WINAPI *)(int, int, int, LPWSAPROTOCOL_INFOW, GROUP, DWORD)"),
    "IsDebuggerPresent":  ("kernel32", "BOOL (WINAPI *)(void)"),
    "SetUnhandledExceptionFilter": ("kernel32", "LPTOP_LEVEL_EXCEPTION_FILTER (WINAPI *)(LPTOP_LEVEL_EXCEPTION_FILTER)"),
    "RtlCaptureContext":  ("ntdll",    "void (WINAPI *)(PCONTEXT)"),
    "CreateFileW":        ("kernel32", "HANDLE (WINAPI *)(LPCWSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE)"),
    "MoveFileExW":        ("kernel32", "BOOL (WINAPI *)(LPCWSTR, LPCWSTR, DWORD)"),
    "CreateSymbolicLinkW":("kernel32", "BOOLEAN (WINAPI *)(LPCWSTR, LPCWSTR, DWORD)"),
    "GetSystemMetrics":   ("user32",   "int (WINAPI *)(int)"),
    "OpenSCManagerW":     ("advapi32", "SC_HANDLE (WINAPI *)(LPCWSTR, LPCWSTR, DWORD)"),
    "StartServiceW":      ("advapi32", "BOOL (WINAPI *)(SC_HANDLE, DWORD, LPCWSTR*)"),
    "OpenServiceW":       ("advapi32", "SC_HANDLE (WINAPI *)(SC_HANDLE, LPCWSTR, DWORD)"),
    "LsaAddAccountRights":("advapi32", "NTSTATUS (WINAPI *)(LSA_HANDLE, PSID, PLSA_UNICODE_STRING, ULONG)"),
    "LsaOpenPolicy":      ("advapi32", "NTSTATUS (WINAPI *)(PLSA_UNICODE_STRING, PLSA_OBJECT_ATTRIBUTES, ACCESS_MASK, PLSA_HANDLE)"),
    "LsaClose":           ("advapi32", "NTSTATUS (WINAPI *)(LSA_HANDLE)"),
    "GetTokenInformation":("advapi32", "BOOL (WINAPI *)(HANDLE, TOKEN_INFORMATION_CLASS, LPVOID, DWORD, PDWORD)"),
    "LocalAlloc":         ("kernel32", "HLOCAL (WINAPI *)(UINT, SIZE_T)"),
    "LocalFree":          ("kernel32", "HLOCAL (WINAPI *)(HLOCAL)"),
    "CloseHandle":        ("kernel32", "BOOL (WINAPI *)(HANDLE)"),
    "GetModuleFileNameW": ("kernel32", "DWORD (WINAPI *)(HMODULE, LPWSTR, DWORD)"),
    "GetLastError":       ("kernel32", "DWORD (WINAPI *)(void)"),
    "FlushInstructionCache": ("kernel32", "BOOL (WINAPI *)(HANDLE, LPCVOID, SIZE_T)"),
    "VirtualFree":        ("kernel32", "BOOL (WINAPI *)(LPVOID, SIZE_T, DWORD)"),
    "GetLargePageMinimum":("kernel32", "SIZE_T (WINAPI *)(void)"),
    "GetCurrentProcess":  ("kernel32", "HANDLE (WINAPI *)(void)"),
    "GetCurrentThreadId": ("kernel32", "DWORD (WINAPI *)(void)"),
    "GetProcAddress":     ("kernel32", "FARPROC (WINAPI *)(HMODULE, LPCSTR)"),
    "LoadLibraryA":       ("kernel32", "HMODULE (WINAPI *)(LPCSTR)"),
    "LoadLibraryW":       ("kernel32", "HMODULE (WINAPI *)(LPCWSTR)"),
    "GetSystemDirectoryA":("kernel32", "UINT (WINAPI *)(LPSTR, UINT)"),
    "SHGetKnownFolderPath":("shell32", "HRESULT (WINAPI *)(REFKNOWNFOLDERID, DWORD, HANDLE, PWSTR*)"),
    # ...可继续补充
}

def find_files(root, exts=('.cpp', '.c', '.h', '.hpp')):
    for base, _, files in os.walk(root):
        for f in files:
            if f.endswith(exts):
                yield os.path.join(base, f)

def insert_huffapi_includes(content):
    if '#include "base/win/HuffApi.h"' not in content:
        content = '#include "base/win/HuffApi.h"\n#include "base/win/HuffApiHashes.h"\n' + content
    return content

def replace_api_calls(content, api, dll, typedef):
    # 替换所有直接调用
    pattern = rf'(?<![a-zA-Z0-9_]){api}\s*\\('
    repl = f'p{api}('
    content = re.sub(pattern, repl, content)
    # 插入动态加载模板
    if f'static {api}_t p{api}' not in content:
        template = f"""
using {api}_t = {typedef};
static {api}_t p{api} = nullptr;
if (!p{api}) {{
    HMODULE hMod = xmrig::HuffApi::getModuleByHash(xmrig::HuffApiHashes::{dll});
    p{api} = ({api}_t)xmrig::HuffApi::getProcByHash(hMod, xmrig::HuffApiHashes::{api});
}}
"""
        content = template + content
    return content

def process_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    orig_content = content
    content = insert_huffapi_includes(content)
    for api, (dll, typedef) in api_map.items():
        if re.search(rf'(?<![a-zA-Z0-9_]){api}\s*\(', content):
            content = replace_api_calls(content, api, dll, typedef)
    if content != orig_content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Processed: {file_path}")

if __name__ == '__main__':
    for file in find_files('src'):
        process_file(file)