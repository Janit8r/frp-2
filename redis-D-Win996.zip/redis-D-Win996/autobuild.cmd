@echo off
REM Redis-D-Win996 automatic build script (with RandomX assembly support)

echo ==== Redis-D-Win996 automatic build script (with RandomX assembly) ====
echo.

REM Check for MSYS2/MinGW environment
where mingw32-make.exe >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Error: mingw32-make.exe not found. Please install MSYS2/MinGW and add it to PATH.
    echo You can download MSYS2 from: https://www.msys2.org/
    echo Then run in MSYS2: pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make
    exit /b 1
)

REM Get script absolute path
set SCRIPT_DIR=%~dp0
set SCRIPT_DIR=%SCRIPT_DIR:~0,-1%

REM Ensure scripts directory exists
if not exist scripts mkdir scripts

REM Check and create assembly comment fix script
if not exist scripts\fix_asm_comments.bat (
    echo Creating assembly comment fix script...
    (
        echo @echo off
        echo REM This script fixes comments in RandomX assembly files for GCC
        echo.
        echo setlocal enabledelayedexpansion
        echo.
        echo set ROOTDIR=%%~dp0..
        echo set ASM_FILES[0]=%%ROOTDIR%%\src\crypto\randomx\jit_compiler_x86_static.S
        echo set ASM_FILES[1]=%%ROOTDIR%%\src\crypto\cn\asm\win64\cn_main_loop.S
        echo set ASM_FILES[2]=%%ROOTDIR%%\src\crypto\cn\asm\CryptonightR_template.S
        echo.
        echo REM Check for sed tool, should be available in MSYS2/MinGW
        echo where sed ^>nul 2^>nul
        echo if %%ERRORLEVEL%% neq 0 ^(
        echo     echo Error: sed tool not found. Please ensure MSYS2 is installed and its bin directory is in PATH.
        echo     exit /b 1
        echo ^)
        echo.
        echo for /L %%%%i in ^(0,1,2^) do ^(
        echo     if exist "^!ASM_FILES[%%%%i]^!" ^(
        echo         echo Processing file: ^!ASM_FILES[%%%%i]^!
        echo         
        echo         REM Create temporary file
        echo         set TMP_FILE=^!ASM_FILES[%%%%i]^!.tmp
        echo         
        echo         REM Replace ';#' comments with '//', which GCC can handle correctly
        echo         sed "s/;#/\/\//g" "^!ASM_FILES[%%%%i]^!" ^> "^!TMP_FILE^!"
        echo         
        echo         REM Replace success, overwrite original file
        echo         move /Y "^!TMP_FILE^!" "^!ASM_FILES[%%%%i]^!" ^>nul
        echo         
        echo         echo Fixed: ^!ASM_FILES[%%%%i]^!
        echo     ^) else ^(
        echo         echo Warning: File does not exist ^!ASM_FILES[%%%%i]^!
        echo     ^)
        echo ^)
        echo.
        echo echo All assembly files processing complete
        echo endlocal
    ) > scripts\fix_asm_comments.bat
)

REM Edit build.cmd to use absolute path
echo Updating build.cmd with absolute path...
(
    echo @echo off
    echo REM Redis-D-Win996 构建脚本
    echo.
    echo echo 正在准备构建环境...
    echo.
    echo REM 创建构建目录
    echo if not exist build mkdir build
    echo.
    echo REM 确保安全模块目录存在
    echo if not exist src\security mkdir src\security
    echo.
    echo REM 修复汇编文件中的注释问题
    echo echo 修复汇编文件中的注释...
    echo if exist scripts\fix_asm_comments.bat ^(
    echo     call scripts\fix_asm_comments.bat
    echo ^) else ^(
    echo     echo 警告: 修复脚本不存在，跳过汇编文件修复
    echo ^)
    echo.
    echo REM 获取当前脚本绝对路径
    echo set SCRIPT_DIR=%%~dp0
    echo set SCRIPT_DIR=%%SCRIPT_DIR:~0,-1%%
    echo.
    echo REM 进入构建目录
    echo cd build
    echo.
    echo echo 运行CMake配置...
    echo cmake "%%SCRIPT_DIR%%" -G "MSYS Makefiles" ^^^^^
    echo -DCMAKE_BUILD_TYPE=Release ^^^^^
    echo -DWITH_SECURITY=ON ^^^^^
    echo -DWITH_C_SECURITY=ON ^^^^^
    echo -DWITH_ASM=ON ^^^^^
    echo -DCMAKE_ASM_FLAGS="-x assembler-with-cpp" ^^^^^
    echo -DCMAKE_CXX_FLAGS="-fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros -Wno-pedantic -Wno-comment -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H" ^^^^^
    echo -DCMAKE_C_FLAGS="-Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-comment -Wno-format-security -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H"
    echo.
    echo if %%ERRORLEVEL%% neq 0 ^(
    echo     echo CMake配置失败，错误代码: %%ERRORLEVEL%%
    echo     exit /b %%ERRORLEVEL%%
    echo ^)
    echo.
    echo echo 先编译安全模块...
    echo cd src\security
    echo cmake --build . -j %%NUMBER_OF_PROCESSORS%%
    echo.
    echo if %%ERRORLEVEL%% neq 0 ^(
    echo     echo 安全模块编译失败，错误代码: %%ERRORLEVEL%%
    echo     cd ..\..
    echo     exit /b %%ERRORLEVEL%%
    echo ^)
    echo.
    echo cd ..\..
    echo.
    echo echo 正在编译整个项目...
    echo cmake --build . -j %%NUMBER_OF_PROCESSORS%%
    echo.
    echo if %%ERRORLEVEL%% neq 0 ^(
    echo     echo 编译失败，错误代码: %%ERRORLEVEL%%
    echo     exit /b %%ERRORLEVEL%%
    echo ^)
    echo.
    echo echo 编译成功完成！
    echo echo.
    echo echo 构建产物位置:
    echo dir /B *.exe
    echo.
    echo cd ..
) > build.cmd

REM Run build script
echo Running build script...
call build.cmd

if %ERRORLEVEL% neq 0 (
    echo.
    echo Build failed, error code: %ERRORLEVEL%
    exit /b %ERRORLEVEL%
)

echo.
echo Build completed successfully!
echo.
echo Build artifacts location:
dir /B build\*.exe
echo.
exit /b 0 