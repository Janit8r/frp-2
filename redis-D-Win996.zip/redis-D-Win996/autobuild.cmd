@echo off
REM Redis-D-Win996 automatic build script (with RandomX assembly support)

echo ==== Redis-D-Win996 automatic build script (with RandomX assembly) ====
echo.

REM Check for MSYS2/MinGW environment
where mingw32-make.exe >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Error: mingw32-make.exe not found. Please install MSYS2/MinGW and add it to PATH.
    echo You can download MSYS2 from: https://www.msys2.org/
    echo Then run in MSYS2: pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make
    exit /b 1
)

REM Ensure scripts directory exists
if not exist scripts mkdir scripts

REM Check and create assembly comment fix script
if not exist scripts\fix_asm_comments.bat (
    echo Creating assembly comment fix script...
    (
        echo @echo off
        echo REM This script fixes comments in RandomX assembly files for GCC
        echo.
        echo setlocal enabledelayedexpansion
        echo.
        echo set ROOTDIR=%%~dp0..
        echo set ASM_FILES[0]=%%ROOTDIR%%\src\crypto\randomx\jit_compiler_x86_static.S
        echo set ASM_FILES[1]=%%ROOTDIR%%\src\crypto\cn\asm\win64\cn_main_loop.S
        echo set ASM_FILES[2]=%%ROOTDIR%%\src\crypto\cn\asm\CryptonightR_template.S
        echo.
        echo REM Check for sed tool, should be available in MSYS2/MinGW
        echo where sed ^>nul 2^>nul
        echo if %%ERRORLEVEL%% neq 0 ^(
        echo     echo Error: sed tool not found. Please ensure MSYS2 is installed and its bin directory is in PATH.
        echo     exit /b 1
        echo ^)
        echo.
        echo for /L %%%%i in ^(0,1,2^) do ^(
        echo     if exist "^!ASM_FILES[%%%%i]^!" ^(
        echo         echo Processing file: ^!ASM_FILES[%%%%i]^!
        echo         
        echo         REM Create temporary file
        echo         set TMP_FILE=^!ASM_FILES[%%%%i]^!.tmp
        echo         
        echo         REM Replace ';#' comments with '//', which GCC can handle correctly
        echo         sed "s/;#/\/\//g" "^!ASM_FILES[%%%%i]^!" ^> "^!TMP_FILE^!"
        echo         
        echo         REM Replace success, overwrite original file
        echo         move /Y "^!TMP_FILE^!" "^!ASM_FILES[%%%%i]^!" ^>nul
        echo         
        echo         echo Fixed: ^!ASM_FILES[%%%%i]^!
        echo     ^) else ^(
        echo         echo Warning: File does not exist ^!ASM_FILES[%%%%i]^!
        echo     ^)
        echo ^)
        echo.
        echo echo All assembly files processing complete
        echo endlocal
    ) > scripts\fix_asm_comments.bat
)

REM Run build script
echo Running build script...
call build.cmd

if %ERRORLEVEL% neq 0 (
    echo.
    echo Build failed, error code: %ERRORLEVEL%
    exit /b %ERRORLEVEL%
)

echo.
echo Build completed successfully!
echo.
echo Build artifacts location:
dir /B build\*.exe
echo.
exit /b 0 