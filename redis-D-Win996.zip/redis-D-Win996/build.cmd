@echo off
REM Redis-D-Win996 构建脚本

echo 正在准备构建环境...

REM 创建构建目录
if not exist build mkdir build

REM 确保安全模块目录存在
if not exist src\security mkdir src\security

REM 修复汇编文件中的注释问题
echo 修复汇编文件中的注释...
if exist scripts\fix_asm_comments.bat (
    call scripts\fix_asm_comments.bat
) else (
    echo 警告: 修复脚本不存在，跳过汇编文件修复
)

REM 进入构建目录
cd build

echo 运行CMake配置...
cmake .. -G "MSYS Makefiles" ^
-DCMAKE_BUILD_TYPE=Release ^
-DWITH_SECURITY=ON ^
-DWITH_C_SECURITY=ON ^
-DWITH_ASM=ON ^
-DCMAKE_ASM_FLAGS="-x assembler-with-cpp" ^
-DCMAKE_CXX_FLAGS="-fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros -Wno-pedantic -Wno-comment -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H" ^
-DCMAKE_C_FLAGS="-Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-comment -Wno-format-security -DWIN32_LEAN_AND_MEAN -DNOMINMAX -DHAVE_WINTERNL_H"

if %ERRORLEVEL% neq 0 (
    echo CMake配置失败，错误代码: %ERRORLEVEL%
    exit /b %ERRORLEVEL%
)

echo 先编译安全模块...
cd src\security
cmake --build . -j %NUMBER_OF_PROCESSORS%

if %ERRORLEVEL% neq 0 (
    echo 安全模块编译失败，错误代码: %ERRORLEVEL%
    cd ..\..
    exit /b %ERRORLEVEL%
)

cd ..\..

echo 正在编译整个项目...
cmake --build . -j %NUMBER_OF_PROCESSORS%

if %ERRORLEVEL% neq 0 (
    echo 编译失败，错误代码: %ERRORLEVEL%
    exit /b %ERRORLEVEL%
)

echo 编译成功完成！
echo.
echo 构建产物位置:
dir /B *.exe

cd .. 