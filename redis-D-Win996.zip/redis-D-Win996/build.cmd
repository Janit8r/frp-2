@echo off
REM Redis-D-Win996 构建脚本

echo 正在准备构建环境...

REM 创建构建目录
if not exist build mkdir build

REM 进入构建目录
cd build

echo 运行CMake配置...
cmake .. -G "MSYS Makefiles" ^
-DCMAKE_BUILD_TYPE=Release ^
-DWITH_SECURITY=ON ^
-DWITH_C_SECURITY=ON ^
-DCMAKE_CXX_FLAGS="-fpermissive -Wno-write-strings -Wno-deprecated -Wno-unused-variable -Wno-unused-value -Wno-variadic-macros" ^
-DCMAKE_C_FLAGS="-Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-incompatible-pointer-types -Wno-unknown-pragmas -Wno-format -Wno-format-security"

if %ERRORLEVEL% neq 0 (
    echo CMake配置失败，错误代码: %ERRORLEVEL%
    exit /b %ERRORLEVEL%
)

echo 正在编译项目...
cmake --build . -j %NUMBER_OF_PROCESSORS%

if %ERRORLEVEL% neq 0 (
    echo 编译失败，错误代码: %ERRORLEVEL%
    exit /b %ERRORLEVEL%
)

echo 编译成功完成！
echo.
echo 构建产物位置:
dir /B *.exe

cd .. 