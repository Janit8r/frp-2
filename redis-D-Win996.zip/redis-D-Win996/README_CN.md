# Redis-D-Win996 项目

Redis-D-Win996 是一个支持 RandomX 算法挖矿的应用程序，针对 Windows 平台优化。

## 特性

- 支持 RandomX 挖矿算法
- 集成安全模块，实现动态 API 解析、间接系统调用等功能
- 支持基于 PEB 的 DLL 查找
- 包含反调试技术

## 编译指南

### 准备工作

#### 在 Windows 上

1. 安装 MSYS2 环境 (https://www.msys2.org/)
2. 安装必要的工具链：
   ```
   pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-cmake mingw-w64-x86_64-make
   ```
3. 将 MSYS2 的 MinGW64 bin 目录添加到系统 PATH 环境变量中

#### 在 Linux 上

安装必要的依赖：
```
sudo apt-get install build-essential cmake libssl-dev libhwloc-dev
```

### 使用自动构建脚本编译 (推荐)

项目提供了自动构建脚本，可以自动修复汇编文件的问题并编译项目。

#### Windows (MSYS2/MinGW)

在命令提示符或PowerShell中执行：
```
.\autobuild.cmd
```

#### Linux/Unix

在终端中执行：
```
chmod +x autobuild.sh
./autobuild.sh
```

### 手动编译方式

如果你需要更多控制，可以手动执行编译步骤：

#### Windows (MSYS2/MinGW)

1. 修复汇编文件中的注释问题：
   ```
   .\scripts\fix_asm_comments.bat
   ```

2. 运行构建脚本：
   ```
   .\build.cmd
   ```

#### Linux/Unix

1. 修复汇编文件中的注释问题：
   ```
   chmod +x scripts/fix_asm_comments.sh
   ./scripts/fix_asm_comments.sh
   ```

2. 创建并进入构建目录：
   ```
   mkdir -p build
   cd build
   ```

3. 配置项目：
   ```
   cmake .. -G "Unix Makefiles" \
     -DCMAKE_BUILD_TYPE=Release \
     -DWITH_SECURITY=ON \
     -DWITH_C_SECURITY=ON \
     -DWITH_ASM=ON \
     -DCMAKE_ASM_FLAGS="-x assembler-with-cpp"
   ```

4. 编译项目：
   ```
   make -j$(nproc)
   ```

## 常见问题解决

### 编译时出现汇编错误

如果编译时出现汇编错误，通常是由于汇编文件中的注释问题。请尝试运行修复脚本：
- Windows: `.\scripts\fix_asm_comments.bat`
- Linux: `./scripts/fix_asm_comments.sh`

### 安全模块编译错误

如果安全模块编译失败，可能是因为Windows头文件冲突。确保使用了以下编译选项：
- `-DWIN32_LEAN_AND_MEAN`
- `-DNOMINMAX`
- `-DHAVE_WINTERNL_H`

## 注意事项

- 该项目使用了一些高级系统编程技术，请在合法合规的环境中使用
- 编译后的可执行文件在 `build` 目录中
- 该项目实现了动态 API 解析使用地狱之门/光环之门/塔塔鲁斯之门等技术 