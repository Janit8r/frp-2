@echo off
REM 此脚本用于修复RandomX汇编文件中的注释，使其可以正确被GCC处理

setlocal enabledelayedexpansion

set ROOTDIR=%~dp0..
set ASM_FILES[0]=%ROOTDIR%\src\crypto\randomx\jit_compiler_x86_static.S
set ASM_FILES[1]=%ROOTDIR%\src\crypto\cn\asm\win64\cn_main_loop.S
set ASM_FILES[2]=%ROOTDIR%\src\crypto\cn\asm\CryptonightR_template.S

REM 检查是否有sed工具，MSYS2/MinGW环境应该有
where sed >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo 错误: 找不到sed工具，请确保安装了MSYS2并将其bin目录添加到PATH中
    exit /b 1
)

for /L %%i in (0,1,2) do (
    if exist "!ASM_FILES[%%i]!" (
        echo 处理文件: !ASM_FILES[%%i]!
        
        REM 创建临时文件
        set TMP_FILE=!ASM_FILES[%%i]!.tmp
        
        REM 替换 ';#' 注释为 '//'，GCC可以正确处理C++风格注释
        sed "s/;#/\/\//g" "!ASM_FILES[%%i]!" > "!TMP_FILE!"
        
        REM 替换成功后覆盖原文件
        move /Y "!TMP_FILE!" "!ASM_FILES[%%i]!" >nul
        
        echo 已修复: !ASM_FILES[%%i]!
    ) else (
        echo 警告: 文件不存在 !ASM_FILES[%%i]!
    )
)

echo 所有汇编文件注释处理完成
endlocal 