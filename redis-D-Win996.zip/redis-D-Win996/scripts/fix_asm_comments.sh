#!/bin/bash
# 此脚本用于修复RandomX汇编文件中的注释，使其可以正确被GCC处理

ROOTDIR="$(cd "$(dirname "$0")/.." && pwd)"
ASM_FILES=(
  "${ROOTDIR}/src/crypto/randomx/jit_compiler_x86_static.S"
  "${ROOTDIR}/src/crypto/cn/asm/win64/cn_main_loop.S"
  "${ROOTDIR}/src/crypto/cn/asm/CryptonightR_template.S"
)

# 遍历所有汇编文件
for file in "${ASM_FILES[@]}"; do
  if [ -f "$file" ]; then
    echo "处理文件: $file"
    
    # 创建临时文件
    TMP_FILE="${file}.tmp"
    
    # 替换 ';#' 注释为 '//'，GCC可以正确处理C++风格注释
    sed 's/;#/\/\//g' "$file" > "$TMP_FILE"
    
    # 替换成功后覆盖原文件
    mv "$TMP_FILE" "$file"
    
    echo "已修复: $file"
  else
    echo "警告: 文件不存在 $file"
  fi
done

echo "所有汇编文件注释处理完成" 