@echo off
cd /d "%~dp0"
testformycode.exe --bench=10M --submit
pause
