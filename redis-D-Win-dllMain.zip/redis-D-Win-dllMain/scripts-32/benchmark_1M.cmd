@echo off
cd /d "%~dp0"
testformycode.exe --bench=1M --submit
pause
