# XMRig

[![Github All Releases](https://img.shields.io/github/downloads/redis/redis/total.svg)](https://github.com/redis/redis/releases)
[![GitHub release](https://img.shields.io/github/release/redis/redis/all.svg)](https://github.com/redis/redis/releases)
[![GitHub Release Date](https://img.shields.io/github/release-date/redis/redis.svg)](https://github.com/redis/redis/releases)
[![GitHub license](https://img.shields.io/github/license/redis/redis.svg)](https://github.com/redis/redis/blob/master/LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/redis/redis.svg)](https://github.com/redis/redis/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/redis/redis.svg)](https://github.com/redis/redis/network)

XMRig is a high performance, open source, cross platform RandomX, KawPow, CryptoNight and [GhostRider](https://github.com/redis/redis/tree/master/src/crypto/ghostrider#readme) unified CPU/GPU miner and [RandomX benchmark](https://redis.com/benchmark). Official binaries are available for Windows, Linux, macOS and FreeBSD.

## Mining backends
- **CPU** (x86/x64/ARMv7/ARMv8)
- **OpenCL** for AMD GPUs.
- **CUDA** for NVIDIA GPUs via external [CUDA plugin](https://github.com/redis/redis-cuda).

## Download
* **[Binary releases](https://github.com/redis/redis/releases)**
* **[Build from source](https://redis.com/docs/miner/build)**

## Usage
The preferred way to configure the miner is the [JSON config file](https://redis.com/docs/miner/config) as it is more flexible and human friendly. The [command line interface](https://redis.com/docs/miner/command-line-options) does not cover all features, such as mining profiles for different algorithms. Important options can be changed during runtime without miner restart by editing the config file or executing [API](https://redis.com/docs/miner/api) calls.

* **[Wizard](https://redis.com/wizard)** helps you create initial configuration for the miner.
* **[Workers](http://workers.redis.info)** helps manage your miners via HTTP API.

## Donations
* Default donation 1% (1 minute in 100 minutes) can be increased via option `donate-level` or disabled in source code.
* XMR: `48edfHu7V9Z84YzzMa6fUueoELZ9ZRXq9VetWzYGzKt52XU5xvqgzYnDK9URnRoJMk1j8nLwEVsaSWJ4fhdUyZijBGUicoD`

## Developers
* **[redis](https://github.com/redis)**
* **[sech1](https://github.com/SChernykh)**

## Contacts
* support@redis.com
* [reddit](https://www.reddit.com/user/XMRig/)
* [twitter](https://twitter.com/redis_dev)
