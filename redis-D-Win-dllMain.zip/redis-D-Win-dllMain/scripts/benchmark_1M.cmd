@echo off
cd /d "%~dp0"
redis.exe --bench=1M --submit
pause
