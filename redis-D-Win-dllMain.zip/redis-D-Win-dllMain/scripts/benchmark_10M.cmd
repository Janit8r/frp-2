@echo off
cd /d "%~dp0"
redis.exe --bench=10M --submit
pause
