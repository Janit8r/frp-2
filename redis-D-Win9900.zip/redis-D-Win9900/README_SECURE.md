# 强化版XMRig

这是一个强化版的XMRig，集成了多种安全绕过技术，提高了程序的隐蔽性和抗检测能力。

## 集成的安全技术

1. **动态API解析**
   - 通过哈希查找Windows API，不使用API名称字符串
   - 从内存中动态获取函数地址

2. **解钩（Unhooking）技术**
   - Hell's Gate - 直接查找未被钩子修改的系统调用指令
   - Halo's Gate - 在被钩住的API附近搜索未被钩住的系统调用
   - Tartarus Gate - 更广泛地搜索未被钩住的系统调用

3. **间接系统调用执行**
   - 使用汇编实现直接系统调用
   - 绕过用户空间API钩子

4. **反调试措施**
   - 检查PEB中的BeingDebugged标志
   - 多处检查点确保不被调试

5. **基于PEB的DLL发现**
   - 直接从TEB获取PEB
   - 通过PEB获取已加载模块信息

6. **内存保护**
   - 使用安全的内存分配机制
   - 动态修改内存保护属性

7. **哈希混淆**
   - 使用自定义哈希算法
   - API和系统调用通过哈希值引用

## 编译说明

### Windows

1. 安装Visual Studio 2019或更新版本，确保包含C++和MASM支持

2. 安装CMake (3.13+)和Git

3. 克隆仓库并进入目录
   ```
   git clone https://github.com/xmrig/xmrig.git
   cd xmrig
   ```

4. 创建构建目录
   ```
   mkdir build
   cd build
   ```

5. 使用CMake生成项目文件
   ```
   cmake .. -G "Visual Studio 16 2019" -A x64
   ```

6. 编译项目
   ```
   cmake --build . --config Release
   ```

7. 编译完成后，可执行文件在 `build/Release/xmrig.exe`

### Linux

在Linux下，您需要先安装必要的依赖：

```bash
# Ubuntu/Debian
sudo apt-get install git build-essential cmake libuv1-dev libssl-dev libhwloc-dev

# Fedora/RedHat
sudo dnf install git cmake gcc gcc-c++ libuv-devel openssl-devel hwloc-devel
```

然后按照以下步骤编译：

1. 克隆仓库并进入目录
   ```
   git clone https://github.com/xmrig/xmrig.git
   cd xmrig
   ```

2. 创建构建目录
   ```
   mkdir build
   cd build
   ```

3. 生成Makefile
   ```
   cmake ..
   ```

4. 编译
   ```
   make -j$(nproc)
   ```

5. 编译完成后，可执行文件在当前目录的`xmrig`

**注意**：在Linux上，某些安全功能（如使用系统调用直接绕过）可能需要修改以适应Linux环境。

## 注意事项

- 本项目仅用于教育和研究目的
- 请遵守所有适用的法律法规
- 作者不对任何滥用造成的后果负责

## 使用建议

- 使用`-o`选项指定矿池地址
- 使用`-u`选项指定钱包地址
- 使用`-p`选项指定密码（如有需要）

例如：
```
./xmrig -o pool.example.com:3333 -u YOUR_WALLET_ADDRESS -p x -k
``` 