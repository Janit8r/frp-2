#!/bin/bash

# AList optimization script for AMD EPYC 7763 Server
# This script applies all optimizations for maximum performance

set -e

echo "==== AList Server Optimization Script ===="
echo "This script will configure your AMD EPYC server for optimal AList performance"

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    echo "Error: This script must be run as root" >&2
    exit 1
fi

# Create directories
echo "Creating necessary directories..."
mkdir -p /opt/alist/data
mkdir -p /opt/alist/data/log
mkdir -p /opt/alist/data/temp
mkdir -p /opt/alist/data/bleve

# Copy configuration files
echo "Copying configuration files..."
cp config.json /opt/alist/data/
cp alist.service /etc/systemd/system/
cp 99-alist-performance.conf /etc/sysctl.d/

# Apply sysctl settings
echo "Applying kernel parameter optimizations..."
sysctl -p /etc/sysctl.d/99-alist-performance.conf

# Configure transparent huge pages for memory optimization
echo "Configuring transparent huge pages..."
echo always > /sys/kernel/mm/transparent_hugepage/enabled

# Create alist user if not exists
if ! id -u alist >/dev/null 2>&1; then
    echo "Creating alist user..."
    useradd -r -s /bin/false alist
fi

# Copy AList files to the installation directory
echo "Copying AList files..."
cp -r * /opt/alist/ 2>/dev/null || true  # Ignore errors from trying to copy directories to themselves

# Set proper permissions
echo "Setting permissions..."
chown -R alist:alist /opt/alist

# Configure scheduler for block devices
echo "Configuring I/O schedulers..."
for device in $(lsblk -d -o NAME | grep -v NAME); do
    if [[ $device == nvme* ]]; then
        echo "mq-deadline" > /sys/block/$device/queue/scheduler 2>/dev/null || true
    else
        echo "bfq" > /sys/block/$device/queue/scheduler 2>/dev/null || true
    fi
done

# Increase file descriptor limits
echo "Configuring file descriptor limits..."
cat > /etc/security/limits.d/99-alist.conf << EOF
alist soft nofile 1000000
alist hard nofile 1000000
alist soft nproc 64000
alist hard nproc 64000
EOF

# Configure ulimit for current session
ulimit -n 1000000

# Setup CPU performance governor if available
if [ -d /sys/devices/system/cpu/cpu0/cpufreq ]; then
    echo "Setting CPU governor to performance..."
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo performance > $cpu 2>/dev/null || true
    done
fi

# Enable and start systemd service
echo "Configuring systemd service..."
systemctl daemon-reload
systemctl enable alist.service
systemctl restart alist.service

echo "Verifying service status..."
systemctl status alist.service --no-pager

echo ""
echo "==== Optimization Complete ===="
echo "AList has been optimized for AMD EPYC 7763 with 64 cores/128 threads"
echo "You can access AList at: http://$(hostname -I | awk '{print $1}'):5244"
echo ""
echo "To monitor performance, use:"
echo "  - CPU/Memory: htop"
echo "  - Disk I/O: iostat -x 5"
echo "  - Network: iftop"
echo ""
echo "For more information, see SERVER-OPTIMIZATION.md" 