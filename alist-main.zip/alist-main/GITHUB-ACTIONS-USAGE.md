# 使用GitHub Actions构建AList

本文档介绍如何使用GitHub Actions自动构建AList项目。

## 准备工作

1. 首先使用打包脚本将项目打包为`abc.zip`：

```bash
# 赋予脚本执行权限
chmod +x create-zip-package.sh

# 执行打包脚本
./create-zip-package.sh
```

2. 上传`abc.zip`到一个可公开访问的位置（例如GitHub Release、对象存储、网盘等）。

## 设置GitHub Actions

1. 将`.github/workflows/build-from-zip.yml`文件添加到你的代码库中。

2. 在GitHub仓库设置中添加Secret：
   - 导航到仓库 -> Settings -> Secrets and variables -> Actions
   - 点击"New repository secret"
   - 名称填写：`ZIP_URL`
   - 值填写：你上传的abc.zip的URL
   - 点击"Add secret"保存

## 触发构建

有三种方式可以触发构建：

1. **自动触发**：当你推送代码到main分支或创建针对main分支的Pull Request时，工作流会自动运行。

2. **手动触发**：
   - 导航到仓库 -> Actions
   - 从左侧菜单选择"Build AList from ZIP"工作流
   - 点击"Run workflow"
   - 点击绿色的"Run workflow"按钮确认

## 获取构建结果

1. 在GitHub仓库页面，点击"Actions"标签
2. 找到最近运行的工作流实例并点击
3. 在工作流详情页面下方的"Artifacts"部分可以下载构建产物：
   - `alist-build`：包含基本构建结果和优化配置
   - 各平台的构建包（如`alist-linux-amd64-package`等）

## 多平台构建

工作流会自动为以下平台构建AList：

- Linux (amd64, arm64)
- Windows (amd64)
- macOS (amd64, arm64)

每个平台的构建包都包含了针对AMD EPYC服务器优化的配置文件。

## 性能优化文件

构建包中包含以下用于性能优化的文件：

1. `data/config.json`：AList应用程序配置
2. `alist.service`：带有资源优化设置的Systemd服务
3. `99-alist-performance.conf`：系统内核参数优化
4. `optimize-server.sh`：自动化部署脚本
5. `SERVER-OPTIMIZATION.md`：优化说明文档

## 注意事项

- 确保`abc.zip`包含正确的源代码和优化配置文件
- 对于生产环境，建议先在测试环境验证构建结果
- 如果需要修改构建配置，可以编辑`.github/workflows/build-from-zip.yml`文件 