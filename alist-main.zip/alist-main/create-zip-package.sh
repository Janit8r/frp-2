#!/bin/bash

# 脚本用于将AList项目打包为abc.zip
# 使用方法: ./create-zip-package.sh

# 确保脚本在出错时退出
set -e

echo "开始打包AList项目为abc.zip..."

# 创建临时目录
TEMP_DIR=$(mktemp -d)
echo "创建临时目录: $TEMP_DIR"

# 复制项目文件到临时目录
echo "复制项目文件..."
cp -r ./* $TEMP_DIR/
cd $TEMP_DIR

# 删除不需要的文件和目录
echo "清理不必要的文件..."
rm -rf .git .github/workflows node_modules .DS_Store *.zip

# 将优化配置文件放到正确位置
echo "确保配置文件就位..."
mkdir -p data
if [ -f config.json ]; then
  mv config.json data/
fi

# 打包为zip
echo "创建abc.zip..."
zip -r abc.zip * .??*

# 将zip文件移动到原始目录
mv abc.zip $OLDPWD/

# 清理
cd $OLDPWD
rm -rf $TEMP_DIR

echo "打包完成！"
echo "文件已保存为: $(pwd)/abc.zip"
echo ""
echo "你可以将此文件上传至服务器或GitHub仓库，然后通过GitHub Actions下载并构建" 